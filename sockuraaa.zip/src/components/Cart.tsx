import React, { useState } from 'react';
import { motion } from 'motion/react';
import { ShoppingCart, Trash2, ArrowRight, ShieldCheck, Copy, Check } from 'lucide-react';
import { OrderItem } from '../types';

interface CartProps {
  cartItems: OrderItem[];
  onUpdateQuantity: (productId: string, delta: number) => void;
  onRemoveItem: (productId: string) => void;
  onCheckout: (refNumber: string, cardNumber: string, phone: string, postalCode: string, address: string, receiptImage?: string) => void;
  onClose: () => void;
}

export default function Cart({
  cartItems,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  onClose,
}: CartProps) {
  const [step, setStep] = useState<'cart' | 'checkout'>('cart');
  const [refNumber, setRefNumber] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [postalCode, setPostalCode] = useState('');
  const [address, setAddress] = useState('');
  const [copied, setCopied] = useState(false);
  const [checkoutError, setCheckoutError] = useState('');
  const [receiptImage, setReceiptImage] = useState<string>('');

  const CARD_NUMBER = '۶۰۳۷-۷۰۱۴-۴۷۰۹-۱۵۲۸';
  const CARD_NUMBER_RAW = '6037701447091528';
  const CARD_OWNER = 'نسترن محمدیان خلیفه کندی';

  const totalPrice = cartItems.reduce((acc, curr) => acc + curr.price * curr.quantity, 0);

  const handleCopyCard = () => {
    navigator.clipboard.writeText(CARD_NUMBER_RAW);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 2 * 1024 * 1024) {
        setCheckoutError('حجم فایل تصویر بیش از حد مجاز (حداکثر ۲ مگابایت) است.');
        return;
      }
      const reader = new FileReader();
      reader.onloadend = () => {
        if (typeof reader.result === 'string') {
          setReceiptImage(reader.result);
          setCheckoutError('');
        }
      };
      reader.readAsDataURL(file);
    }
  };

  const handleCompletePayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!refNumber.trim()) {
      setCheckoutError('لطفاً شماره پیگیری یا نام پرداخت‌کننده را وارد کنید تا پرداخت شما توسط ادمین تایید شود.');
      return;
    }
    if (!receiptImage) {
      setCheckoutError('لطفاً عکسی از رسید یا فیش انتقال وجه خود را آپلود کنید تا ادمین بتواند آن را بررسی و تایید کند.');
      return;
    }
    if (!phoneNumber.trim()) {
      setCheckoutError('لطفاً شماره تلفن همراه خود را جهت هماهنگی ارسال وارد کنید.');
      return;
    }
    if (!postalCode.trim()) {
      setCheckoutError('لطفاً کد پستی ۱۰ رقمی خود را وارد کنید.');
      return;
    }
    if (!address.trim()) {
      setCheckoutError('لطفاً آدرس محل زندگی خود را وارد کنید.');
      return;
    }
    
    onCheckout(refNumber.trim(), CARD_NUMBER, phoneNumber.trim(), postalCode.trim(), address.trim(), receiptImage);
    setStep('cart');
    setRefNumber('');
    setPhoneNumber('');
    setPostalCode('');
    setAddress('');
    setReceiptImage('');
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR');
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-xs">
      {/* Click outside to close */}
      <div className="absolute inset-0 -z-10" onClick={onClose} />

      <motion.div
        initial={{ x: '100%' }}
        animate={{ x: 0 }}
        exit={{ x: '100%' }}
        transition={{ type: 'spring', damping: 25, stiffness: 200 }}
        className="w-full max-w-md bg-white h-full flex flex-col justify-between shadow-2xl overflow-hidden"
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-200 flex items-center justify-between bg-slate-900 text-white">
          <div className="flex items-center gap-2">
            <ShoppingCart className="h-5 w-5 text-orange-500" />
            <h2 className="text-base sm:text-lg font-extrabold flex items-center gap-1">
              {step === 'cart' ? 'سبد خرید شما' : 'مراحل ثبت سفارش و پرداخت'}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white font-bold text-xs bg-white/10 px-3 py-1.5 rounded-lg cursor-pointer transition-colors"
          >
            بستن سبد
          </button>
        </div>

        {/* Content Body */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6">
          {step === 'cart' ? (
            /* --- STEP 1: CART LIST --- */
            cartItems.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center p-8 text-center">
                <div className="bg-slate-50 h-16 w-16 rounded-full flex items-center justify-center mb-4 border border-slate-100">
                  <ShoppingCart className="h-8 w-8 text-slate-400" />
                </div>
                <h3 className="text-sm font-bold text-slate-700">سبد خرید شما خالی است</h3>
                <p className="mt-2 text-xs text-slate-400 max-w-[200px] leading-relaxed">
                  جوراب‌های مورد علاقه خود را انتخاب کنید و آنها را به سبد خریدتان بیفزایید.
                </p>
                <button
                  onClick={onClose}
                  className="mt-5 text-xs text-white bg-orange-500 py-2.5 px-5 rounded-xl font-bold cursor-pointer hover:bg-orange-600 transition-colors shadow-sm"
                >
                  مشاهده همه جوراب‌ها
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                {cartItems.map((item) => (
                  <div key={item.productId} className="flex gap-3 bg-slate-50/50 p-3 rounded-2xl border border-slate-200 shadow-xs">
                    <div className="h-16 w-16 bg-white border border-slate-200 rounded-xl p-1.5 flex items-center justify-center shrink-0">
                      <img src={item.image} alt={item.name} className="object-contain max-h-full" referrerPolicy="no-referrer" />
                    </div>
                    
                    <div className="flex-1 flex flex-col justify-between min-w-0">
                      <div>
                        <h4 className="text-xs font-bold text-slate-800 truncate mb-1">{item.name}</h4>
                        <span className="text-[11px] font-semibold text-slate-400 block font-sans">{formatPrice(item.price)} تومان</span>
                      </div>

                      {/* Controls */}
                      <div className="flex justify-between items-center mt-1">
                        <div className="flex items-center gap-1 border border-slate-200 rounded-xl bg-white p-1">
                          <button
                            onClick={() => onUpdateQuantity(item.productId, -1)}
                            className="px-1.5 py-0.5 hover:bg-slate-50 text-slate-500 cursor-pointer rounded-md font-bold font-sans"
                          >
                            -
                          </button>
                          <span className="text-xs font-bold w-6 text-center text-slate-700 font-sans">{item.quantity.toLocaleString('fa-IR')}</span>
                          <button
                            onClick={() => onUpdateQuantity(item.productId, 1)}
                            className="px-1.5 py-0.5 hover:bg-slate-50 text-slate-500 cursor-pointer rounded-md font-bold font-sans"
                          >
                            +
                          </button>
                        </div>

                        <button
                          onClick={() => onRemoveItem(item.productId)}
                          className="text-orange-500 hover:bg-orange-50 p-1.5 rounded-lg transition-colors cursor-pointer"
                          title="حذف"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )
          ) : (
            /* --- STEP 2: CHECKOUT INFO --- */
            <div className="space-y-5">
              <div className="bg-orange-50/70 text-orange-950 p-4 rounded-2xl border border-orange-100 text-xs leading-relaxed space-y-2">
                <p className="font-bold">دستورالعمل پرداخت کارت به کارت:</p>
                <p>مشتری گرامی، جهت تکمیل نهایی سفارش خود، لطفاً مبلغ کامل جوراب‌های انتخابی خود را به صورت کارت به کارت واریز کرده و اطلاعات رسید خود را ثبت کنید.</p>
              </div>

              {/* Total Payment Price Box */}
              <div className="bg-slate-50 border border-slate-200 p-4 rounded-2xl text-center">
                <span className="text-[11px] text-slate-400 block">مبلغ قابل پرداخت نهایی</span>
                <strong className="text-2xl font-black text-slate-900 font-sans">{formatPrice(totalPrice)}</strong>
                <span className="text-xs text-slate-500 mr-1">تومان</span>
              </div>

              {/* Card specifications holder */}
              <div className="border border-slate-200 rounded-2xl p-4 bg-white shadow-xs space-y-4">
                <div>
                  <span className="text-xs text-slate-400 block mb-1 font-semibold">شماره کارت مقصد جهت انتقال وجه</span>
                  <div className="flex items-center justify-between bg-slate-100/55 px-3 py-2 rounded-lg border border-slate-200">
                    <span className="font-sans text-xs sm:text-sm font-extrabold tracking-widest text-slate-800" dir="ltr">
                      {CARD_NUMBER}
                    </span>
                    <button
                      onClick={handleCopyCard}
                      type="button"
                      className="cursor-pointer font-bold text-[10px] text-orange-600 hover:text-orange-700 flex items-center gap-1 bg-orange-50 px-2 py-1 rounded-lg border border-orange-200"
                    >
                      {copied ? <Check className="h-3 w-3 text-emerald-600" /> : <Copy className="h-3 w-3" />}
                      <span>{copied ? 'کپی شد' : 'کپی شماره کارت'}</span>
                    </button>
                  </div>
                </div>

                <div className="text-[11px] text-slate-700 font-bold bg-emerald-50 border border-emerald-100 rounded-xl p-3 space-y-1">
                  <div className="flex items-center gap-1 text-emerald-800">
                    <ShieldCheck className="h-4 w-4 text-emerald-600 shrink-0" />
                    <span>مالک حساب کارت: {CARD_OWNER}</span>
                  </div>
                  <p className="text-[10px] text-emerald-600 font-medium font-sans leading-relaxed">
                     همکاران ما در sockuraaa نام نسترن محمدیان خلیفه کندی را تایید رسمی می‌کنند. لطفاً هنگام ثبت حواله یا انتقال، به تطابق نام روی فیش خود اطمینان یابید.
                  </p>
                </div>
              </div>

               {/* Ref number form */}
              <form onSubmit={handleCompletePayment} className="space-y-4">
                {checkoutError && (
                  <div className="text-[11px] text-orange-600 font-bold bg-orange-50 border border-orange-100 p-2.5 rounded-lg">{checkoutError}</div>
                )}

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    شماره پیگیری واریز یا نام واریزکننده:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: تراکنش ۱۲۹۴۷۲ یا به نام رسول علیزاده"
                    value={refNumber}
                    onChange={(e) => { setRefNumber(e.target.value); setCheckoutError(''); }}
                    className="w-full text-xs font-semibold rounded-xl border border-slate-200 px-4 py-2.5 text-right text-slate-800 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none placeholder:text-slate-400"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1.5">
                    عکس رسید یا تصویر فیش انتقال وجه: <span className="text-orange-500">*</span>
                  </label>
                  {!receiptImage ? (
                    <div className="border-2 border-dashed border-slate-200 hover:border-orange-400 rounded-xl bg-slate-50 p-4 transition-colors text-center relative cursor-pointer">
                      <input
                        type="file"
                        accept="image/*"
                        onChange={handleFileChange}
                        className="absolute inset-0 opacity-0 cursor-pointer h-full w-full"
                      />
                      <div className="space-y-1">
                        <span className="text-xs text-slate-500 font-bold block">جهت آپلود، عکس رسید را اینجا رها کنید یا کلیک کنید</span>
                        <span className="text-[10px] text-slate-400 block font-sans">فقط تصویر (حداکثر ۲ مگابایت)</span>
                      </div>
                    </div>
                  ) : (
                    <div className="relative border border-slate-200 rounded-xl p-2.5 bg-slate-50 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <img src={receiptImage} alt="رسيد" className="h-12 w-12 object-cover rounded-md border border-slate-200" />
                        <div>
                          <span className="text-[11px] font-bold text-slate-700 block">تصویر رسید بارگذاری شد</span>
                          <span className="text-[9px] text-emerald-600 font-medium">آماده جهت ارسال و بررسی ادمین</span>
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => setReceiptImage('')}
                        className="text-[10px] bg-orange-100 hover:bg-orange-200 text-orange-600 px-2 py-1 rounded-md font-bold transition-all cursor-pointer"
                      >
                        تغییر عکس
                      </button>
                    </div>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    شماره تلفن همراه جهت هماهنگی و ارسال:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: ۰۹۱۲۳۴۵۶۷۸۹"
                    value={phoneNumber}
                    onChange={(e) => { setPhoneNumber(e.target.value); setCheckoutError(''); }}
                    className="w-full text-xs font-semibold rounded-xl border border-slate-200 px-4 py-2.5 text-left focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none font-sans"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    کد پستی (۱۰ رقمی):
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: ۱۲۳۴۵۶۷۸۹۰"
                    value={postalCode}
                    onChange={(e) => { setPostalCode(e.target.value); setCheckoutError(''); }}
                    className="w-full text-xs font-semibold rounded-xl border border-slate-200 px-4 py-2.5 text-left focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none font-sans"
                    dir="ltr"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">
                    آدرس دقیق محل زندگی (جهت تحویل پست):
                  </label>
                  <textarea
                    required
                    rows={2}
                    placeholder="استان، شهر، خیابان، کوچه، پلاک، واحد..."
                    value={address}
                    onChange={(e) => { setAddress(e.target.value); setCheckoutError(''); }}
                    className="w-full text-xs font-semibold rounded-xl border border-slate-200 px-4 py-2.5 text-right text-slate-800 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none resize-none"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full cursor-pointer rounded-xl bg-orange-500 hover:bg-orange-600 py-3 text-sm font-semibold text-white transition-all shadow-sm flex items-center justify-center gap-2"
                >
                  <span>ثبت نهایی سفارش و ارسال به ادمین</span>
                </button>
              </form>

              <button
                onClick={() => setStep('cart')}
                className="w-full text-xs text-slate-500 py-2 border border-slate-200 rounded-xl hover:bg-slate-50 flex items-center justify-center gap-1.5 cursor-pointer font-semibold"
              >
                <ArrowRight className="h-3.5 w-3.5" />
                <span>بازگشت به لیست خریدها</span>
              </button>
            </div>
          )}
        </div>

        {/* Footer price calculate / Proceed to next */}
        {step === 'cart' && cartItems.length > 0 && (
          <div className="p-4 sm:p-6 border-t border-slate-200 bg-slate-50/50">
            <div className="flex justify-between items-center mb-4">
              <span className="text-xs font-extrabold text-slate-400">جمع کل سبد خرید</span>
              <div className="text-left font-black text-lg text-slate-900 font-sans">
                <span>{formatPrice(totalPrice)}</span>
                <span className="text-[11px] text-slate-500 font-normal mr-1">تومان</span>
              </div>
            </div>

            <button
              onClick={() => setStep('checkout')}
              className="w-full cursor-pointer rounded-xl bg-orange-500 hover:bg-orange-600 py-3 text-white font-bold text-sm tracking-tight transition-all shadow-sm flex items-center justify-center gap-2"
            >
              <span>ادامه فرآیند خرید جوراب</span>
            </button>
          </div>
        )}
      </motion.div>
    </div>
  );
}
