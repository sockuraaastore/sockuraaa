import React from 'react';
import { X, Megaphone, Calendar, ShieldCheck } from 'lucide-react';
import { PromoBanner } from '../types';

interface BannerDetailModalProps {
  banner: PromoBanner;
  onClose: () => void;
}

export default function BannerDetailModal({ banner, onClose }: BannerDetailModalProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/60 backdrop-blur-md animate-fade-in">
      <div className="bg-white w-full max-w-2xl rounded-3xl overflow-hidden shadow-2xl border border-slate-100 flex flex-col max-h-[90vh]">
        
        {/* Header bar area */}
        <div className="p-4 bg-slate-50 border-b border-slate-100 flex items-center justify-between shrink-0 direction-rtl">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 bg-orange-100 text-orange-600 rounded-xl flex items-center justify-center">
              <Megaphone className="h-4.5 w-4.5" />
            </div>
            <div>
              <span className="text-[10px] font-bold text-slate-400 block">اطلاعیه و پیشنهاد ویژه ساکورا</span>
              <h2 className="text-xs font-black text-slate-700 truncate max-w-[280px] sm:max-w-[400px]">
                {banner.title}
              </h2>
            </div>
          </div>

          <button
            onClick={onClose}
            className="h-8 w-8 rounded-xl hover:bg-slate-200/70 border border-slate-200/50 flex items-center justify-center text-slate-400 hover:text-slate-700 cursor-pointer transition-colors"
          >
            <X className="h-4.5 w-4.5" />
          </button>
        </div>

        {/* Scrollable details container */}
        <div className="p-6 overflow-y-auto space-y-5 text-right flex-1" dir="rtl">
          {/* Banner Hero Image */}
          <div className="relative h-56 sm:h-72 w-full rounded-2xl overflow-hidden shadow-xs border border-slate-200/60 shrink-0 bg-slate-100">
            <img
              src={banner.image}
              alt={banner.title}
              className="h-full w-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1582966772680-860e372bb558?w=800&q=80';
              }}
            />
            <div className="absolute top-3 right-3 bg-orange-500 text-white font-black text-[9px] px-2.5 py-1 rounded-md shadow-sm">
              پیشنهاد ویژه روز
            </div>
          </div>

          {/* Title banner */}
          <h1 className="text-base sm:text-lg font-black text-slate-900 leading-normal border-b border-slate-100 pb-2">
            {banner.title}
          </h1>

          {/* Meta specs info */}
          <div className="flex flex-wrap gap-4 text-[10px] text-slate-400 font-sans font-semibold">
            <span className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded-md">
              <Calendar className="h-3 w-3 text-slate-400" />
              تاریخ فعال‌سازی: امروز (زمان واقعی)
            </span>
            <span className="flex items-center gap-1 bg-slate-100 px-2 py-1 rounded-md text-emerald-600">
              <ShieldCheck className="h-3 w-3" />
              تایید صحت خبر: فروشگاه تخصصی sockuraaa
            </span>
          </div>

          {/* Details main textbox description */}
          <div className="bg-slate-50 border border-slate-200/70 rounded-2xl p-5 text-xs sm:text-sm text-slate-700 leading-loose font-medium text-justify font-sans whitespace-pre-wrap">
            {banner.content}
          </div>
        </div>

        {/* Footer with closed action button */}
        <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end shrink-0">
          <button
            onClick={onClose}
            className="cursor-pointer bg-slate-800 hover:bg-slate-950 text-white font-bold text-xs px-6 py-2.5 rounded-xl transition-colors shadow-xs"
          >
            متوجه شدم، بازگشت به فروشگاه
          </button>
        </div>

      </div>
    </div>
  );
}
