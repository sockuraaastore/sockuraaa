import React, { useState } from 'react';
import { motion } from 'motion/react';
import { X, Star, ShoppingCart, MessageSquare, Trash2, Award, Plus, Minus, User, Calendar } from 'lucide-react';
import { SockProduct, Comment, UserSession } from '../types';

interface ProductDetailModalProps {
  product: SockProduct;
  session: UserSession;
  onClose: () => void;
  onAddToCart: (product: SockProduct, quantity: number) => void;
  onAddComment: (productId: string, comment: Omit<Comment, 'id' | 'date' | 'isFeatured'>) => void;
  onDeleteComment: (productId: string, commentId: string) => void;
  onToggleBestComment: (productId: string, commentId: string) => void;
}

export default function ProductDetailModal({
  product,
  session,
  onClose,
  onAddToCart,
  onAddComment,
  onDeleteComment,
  onToggleBestComment,
}: ProductDetailModalProps) {
  const [quantity, setQuantity] = useState(1);
  const [newCommentText, setNewCommentText] = useState('');
  const [newCommentRating, setNewCommentRating] = useState(5);
  const [commentError, setCommentError] = useState('');

  // Sorter: push featured (best) comments to the top, then sort by date or id descending
  const sortedComments = [...product.comments].sort((a, b) => {
    if (a.isFeatured && !b.isFeatured) return -1;
    if (!a.isFeatured && b.isFeatured) return 1;
    return 0; // maintain relative order
  });

  const handleCommentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCommentText.trim()) {
      setCommentError('لطفاً متن نظر خود را وارد کنید.');
      return;
    }
    onAddComment(product.id, {
      userName: session.name,
      rating: newCommentRating,
      text: newCommentText.trim(),
    });
    setNewCommentText('');
    setNewCommentRating(5);
    setCommentError('');
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR');
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-xs p-4 overflow-y-auto">
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: 30 }}
        className="relative bg-white w-full max-w-4xl rounded-3xl shadow-2xl overflow-hidden my-8 border border-slate-200"
      >
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 left-4 z-10 p-2.5 rounded-full bg-white/85 text-slate-500 hover:text-orange-600 transition-colors cursor-pointer border border-slate-200 shadow-sm"
          aria-label="بستن"
        >
          <X className="h-5 w-5" />
        </button>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-0 max-h-[90vh] overflow-y-auto">
          {/* Right Column: Image and Specs */}
          <div className="p-6 md:p-8 bg-slate-50/50 flex flex-col justify-between border-l border-slate-200">
            <div>
              {/* Product Category & Image */}
              <div className="flex justify-between items-center mb-4">
                <span className="text-xs font-bold text-orange-600 bg-orange-50 px-3 py-1 rounded-full">
                  {product.category}
                </span>
                <span className="text-xs text-slate-400">شناسه جوراب: #{product.id}</span>
              </div>

              <div className="aspect-square w-full rounded-2xl bg-white p-6 border border-slate-100 flex items-center justify-center mb-6 shadow-xs">
                <img
                  src={product.image}
                  alt={product.name}
                  referrerPolicy="no-referrer"
                  className="max-h-[300px] object-contain"
                />
              </div>

              {/* Specs */}
              <div>
                <h4 className="text-sm font-extrabold text-slate-800 mb-3 pb-1.5 border-b border-slate-200">
                  مشخصات کامل جوراب
                </h4>
                <div className="grid grid-cols-2 gap-3 text-xs">
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <span className="text-slate-400 block mb-1">جنس بافت</span>
                    <strong className="text-slate-800">{product.specs.material || 'نخ پنبه سوپر'}</strong>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <span className="text-slate-400 block mb-1">سایز</span>
                    <strong className="text-slate-800">{product.specs.size || 'فری سایز'}</strong>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <span className="text-slate-400 block mb-1">نوع کاربری</span>
                    <strong className="text-slate-800">{product.specs.type || 'اسپرت'}</strong>
                  </div>
                  <div className="bg-white p-2.5 rounded-xl border border-slate-200">
                    <span className="text-slate-400 block mb-1">میزان ضخامت</span>
                    <strong className="text-slate-800">{product.specs.thickness || 'متوسط'}</strong>
                  </div>
                </div>
              </div>
            </div>

            {/* Price & Add to Cart Action */}
            {!session.isAdmin && (
              <div className="mt-8 pt-6 border-t border-slate-200 flex flex-col sm:flex-row gap-4 items-center justify-between">
                <div className="text-right">
                  <span className="text-xs text-slate-400 block mb-0.5">قیمت واحد</span>
                  <div className="flex items-baseline gap-1">
                    <span className="text-2xl font-black text-slate-900">{formatPrice(product.price)}</span>
                    <span className="text-xs text-slate-500">تومان</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 w-full sm:w-auto">
                  {/* Quantity selector */}
                  <div className="flex items-center border border-slate-205 rounded-xl bg-white p-1 shadow-xs">
                    <button
                      onClick={() => setQuantity(q => Math.max(1, q - 1))}
                      className="p-1.5 rounded-lg hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer"
                    >
                      <Minus className="h-4 w-4" />
                    </button>
                    <span className="w-10 text-center font-bold text-sm text-slate-800">{quantity.toLocaleString('fa-IR')}</span>
                    <button
                      onClick={() => setQuantity(q => q + 1)}
                      className="p-1.5 rounded-lg hover:bg-slate-50 text-slate-600 transition-colors cursor-pointer"
                    >
                      <Plus className="h-4 w-4" />
                    </button>
                  </div>

                  <button
                    onClick={() => {
                      onAddToCart(product, quantity);
                      onClose();
                    }}
                    className="flex-1 sm:flex-initial flex items-center justify-center gap-2 cursor-pointer bg-orange-500 hover:bg-orange-600 text-white font-semibold px-6 py-3 rounded-xl transition-all shadow-sm"
                  >
                    <ShoppingCart className="h-4 w-4" />
                    <span>افزودن به سبد</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Left Column: Details, Comments */}
          <div className="p-6 md:p-8 flex flex-col h-full overflow-hidden max-h-[90vh]">
            {/* Sock Name & Description */}
            <div className="mb-6">
              <h1 className="text-xl font-bold text-slate-900 leading-snug mb-3">
                {product.name}
              </h1>
              <p className="text-sm text-slate-500 leading-relaxed text-slate-600">
                {product.description}
              </p>
            </div>

            {/* Commet Box List Header */}
            <div className="flex-1 flex flex-col min-h-0">
              <h3 className="text-sm font-extrabold text-slate-800 mb-3 flex items-center gap-2 border-b border-slate-100 pb-2 shrink-0">
                <MessageSquare className="h-4 w-4 text-orange-500" />
                <span>نظرات خریداران</span>
                <span className="text-xs bg-slate-100 px-2.5 py-0.5 rounded-full text-slate-500 font-semibold font-sans">
                  {product.comments.length.toLocaleString('fa-IR')} نظر
                </span>
              </h3>

              {/* Scroller for Comments */}
              <div className="flex-1 overflow-y-auto space-y-4 pr-1 mb-4 pb-2">
                {sortedComments.length === 0 ? (
                  <p className="text-center text-xs text-slate-400 py-8">هنوز هیچ نظری برای این محصول ثبت نشده است. اولین نظر را شما بگذارید!</p>
                ) : (
                  sortedComments.map((comment) => (
                    <div 
                      key={comment.id} 
                      className={`p-3.5 rounded-2xl border transition-all ${
                        comment.isFeatured 
                          ? 'bg-amber-50/50 border-amber-205 shadow-xs' 
                          : 'bg-slate-50/40 border-slate-200'
                      }`}
                    >
                      <div className="flex justify-between items-start mb-2 gap-2">
                        {/* User, Date & Star rating */}
                        <div className="flex items-center gap-2">
                          <div className={`h-7 w-7 rounded-lg flex items-center justify-center text-xs ${comment.isFeatured ? 'bg-amber-100 text-amber-700' : 'bg-slate-200 text-slate-600'}`}>
                            <User className="h-4 w-4" />
                          </div>
                          <div>
                            <span className="text-xs font-bold text-slate-700 block">{comment.userName}</span>
                            <span className="text-[9px] text-slate-400 flex items-center gap-1 font-sans">
                              <Calendar className="h-3 w-3" />
                              {comment.date}
                            </span>
                          </div>
                        </div>

                        <div className="flex flex-col items-end gap-1">
                          {/* Star representation */}
                          <div className="flex gap-0.5" dir="ltr">
                            {[...Array(5)].map((_, i) => (
                              <Star
                                key={i}
                                className={`h-3 w-3 ${
                                  i < comment.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'
                                }`}
                              />
                            ))}
                          </div>
                          
                          {/* Tag of best comment */}
                          {comment.isFeatured && (
                            <span className="text-[9px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded flex items-center gap-0.5 shrink-0 mt-0.5">
                              <Award className="h-3 w-3" />
                              بهترین نظر
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Text of comment */}
                      <p className="text-xs text-slate-600 leading-relaxed pr-1 mt-2">{comment.text}</p>

                      {/* Admin Controls */}
                      {session.isAdmin && (
                        <div className="mt-3 pt-2.5 border-t border-slate-200/50 flex justify-end gap-3">
                          <button
                            onClick={() => onToggleBestComment(product.id, comment.id)}
                            className={`flex items-center gap-1.5 text-[10px] font-bold px-2 py-1 rounded-lg cursor-pointer transition-colors ${
                              comment.isFeatured
                                ? 'bg-amber-100 hover:bg-amber-200 text-amber-800'
                                : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                            }`}
                          >
                            <Award className="h-3.5 w-3.5" />
                            <span>{comment.isFeatured ? 'حذف از برترین‌ها' : 'انتخاب به عنوان بهترین نظر'}</span>
                          </button>
                          
                          <button
                            onClick={() => onDeleteComment(product.id, comment.id)}
                            className="flex items-center gap-1.5 text-[10px] font-bold text-orange-600 bg-orange-50 hover:bg-orange-100 px-2 py-1 rounded-lg cursor-pointer transition-colors border border-orange-200/50"
                          >
                            <Trash2 className="h-3.5 w-3.5" />
                            <span>حذف نظر</span>
                          </button>
                        </div>
                      )}
                    </div>
                  ))
                )}
              </div>

              {/* Leave a Comment form - only for normal users */}
              {!session.isAdmin && (
                <form onSubmit={handleCommentSubmit} className="border-t border-slate-100 pt-4 shrink-0">
                  <span className="text-xs font-bold text-slate-700 block mb-2">ثبت نظر جدید</span>
                  
                  {commentError && (
                    <div className="text-[11px] text-orange-600 mb-2">{commentError}</div>
                  )}

                  <div className="flex gap-3 mb-2 items-center">
                    <span className="text-xs text-slate-500">امتیاز شما به این جوراب:</span>
                    <div className="flex gap-1" dir="ltr">
                      {[1, 2, 3, 4, 5].map((star) => (
                        <button
                          key={star}
                          type="button"
                          onClick={() => setNewCommentRating(star)}
                          className="p-0.5 cursor-pointer hover:scale-110 transition-transform"
                        >
                          <Star
                            className={`h-5 w-5 ${
                              star <= newCommentRating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'
                            }`}
                          />
                        </button>
                      ))}
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="متن نظر شما درباره کیفیت، دوخت و طرح..."
                      value={newCommentText}
                      onChange={(e) => { setNewCommentText(e.target.value); setCommentError(''); }}
                      className="flex-1 text-xs bg-slate-50 border border-slate-200 focus:border-orange-500 focus:ring-1 focus:ring-orange-500 outline-none rounded-xl px-3 py-2.5 text-slate-800"
                    />
                    <button
                      type="submit"
                      className="cursor-pointer bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs px-4 py-2.5 rounded-xl transition-colors shrink-0 shadow-sm"
                    >
                      ارسال نظر
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>

        </div>
      </motion.div>
    </div>
  );
}
