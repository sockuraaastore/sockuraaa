import React, { useState } from 'react';
import { Send, MessageSquare, ShieldAlert, CheckCheck, HelpCircle } from 'lucide-react';
import { SupportTicket, UserSession } from '../types';

interface SupportChatProps {
  tickets: SupportTicket[];
  session: UserSession;
  onSendMessage: (text: string) => void;
}

export default function SupportChat({ tickets, session, onSendMessage }: SupportChatProps) {
  const [inputText, setInputText] = useState('');
  
  // Find ticket corresponding to this user
  const userTicket = tickets.find(t => t.userPhone === session.phone || t.userId === session.phone);

  const handleSend = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inputText.trim()) return;
    onSendMessage(inputText.trim());
    setInputText('');
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden flex flex-col h-[550px]">
      {/* Header */}
      <div className="bg-slate-900 text-white p-5 shrink-0 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <MessageSquare className="h-5 w-5 text-orange-400" />
          <div>
            <h2 className="text-base font-extrabold leading-none">پشتیبانی آنلاین sockuraaa</h2>
            <span className="text-[10px] text-slate-400 block mt-1.5 font-sans">آماده پاسخگویی به سوالات و مشکلات واریزی شما</span>
          </div>
        </div>
        <div className="bg-white/10 backdrop-blur-xs text-[10px] font-bold px-2.5 py-1 rounded-lg">
          پاسخگویی سریع
        </div>
      </div>

      {/* Message Area */}
      <div className="flex-1 overflow-y-auto p-4 bg-slate-50 space-y-4">
        {!userTicket || userTicket.messages.length === 0 ? (
          /* Empty Chat Area */
          <div className="h-full flex flex-col items-center justify-center text-center p-6">
            <div className="bg-white h-14 w-14 rounded-full flex items-center justify-center border border-slate-200 shadow-sm text-orange-500 mb-4 animate-bounce-short">
              <HelpCircle className="h-7 w-7" />
            </div>
            <h3 className="text-sm font-extrabold text-slate-800">چگونه می‌توانیم به شما کمک کنیم؟</h3>
            <p className="mt-2 text-xs text-slate-400 max-w-sm leading-relaxed">
              هرگونه سوالی درباره کیفیت جوراب‌ها، سایزبندی، زمان تحویل پستی یا وضعیت ترخیص پرداختی کارت‌به‌کارت دارید را در کادر زیر بنویسید. ادمین به زودی در همین صفحه به شما پاسـخ می‌دهد!
            </p>
          </div>
        ) : (
          /* Actual dialogue */
          userTicket.messages.map((msg) => {
            const isAdmin = msg.sender === 'admin';
            return (
              <div
                key={msg.id}
                className={`flex flex-col max-w-[80%] ${isAdmin ? 'mr-auto items-start' : 'ml-auto items-end'}`}
              >
                {/* Sender badge */}
                <span className="text-[10px] text-slate-400 font-bold mb-1 px-1">
                  {isAdmin ? 'مدیریت sockuraaa' : 'شما'}
                </span>

                <div
                  className={`rounded-2xl px-4 py-2.5 text-xs font-semibold leading-relaxed ${
                    isAdmin
                      ? 'bg-white border border-slate-200 text-slate-800 rounded-tr-xs shadow-xs'
                      : 'bg-orange-500 text-white rounded-tl-xs shadow-xs'
                  }`}
                >
                  <p>{msg.text}</p>
                </div>

                <span className="text-[9px] text-slate-400 font-sans mt-0.5 flex items-center gap-1">
                  {msg.timestamp}
                  {!isAdmin && <CheckCheck className="h-3 w-3 text-orange-400" />}
                </span>
              </div>
            );
          })
        )}
      </div>

      {/* Send Input Bar */}
      <form onSubmit={handleSend} className="p-3 border-t border-slate-100 bg-white shrink-0 flex gap-2">
        <input
          type="text"
          placeholder="پیام خود را به ادمین بنویسید..."
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          className="flex-1 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5 text-xs outline-none focus:bg-white focus:border-orange-500 font-medium transition-all"
        />
        <button
          type="submit"
          className="cursor-pointer bg-orange-500 hover:bg-orange-600 text-white p-2.5 rounded-xl transition-colors flex items-center justify-center shrink-0 shadow-sm"
        >
          <Send className="h-4 w-4 transform rotate-180" />
        </button>
      </form>
    </div>
  );
}
