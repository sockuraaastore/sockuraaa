import React, { useState } from 'react';
import { Tag, Plus, Trash2, Edit2, Check, X, ClipboardList, MessageSquare, Star, Award, Image as ImageIcon, HeartHandshake, Megaphone } from 'lucide-react';
import { SockProduct, Order, SupportTicket, Comment, PromoBanner } from '../types';

interface AdminPanelProps {
  products: SockProduct[];
  categories: string[];
  orders: Order[];
  tickets: SupportTicket[];
  banners: PromoBanner[];
  onAddProduct: (product: SockProduct) => void;
  onUpdateProduct: (product: SockProduct) => void;
  onDeleteProduct: (productId: string) => void;
  onAddCategory: (category: string) => void;
  onDeleteCategory: (category: string) => void;
  onUpdateOrderStatus: (orderId: string, status: Order['status'], adminNotes?: string) => void;
  onReplyToTicket: (ticketId: string, text: string) => void;
  onDeleteComment: (productId: string, commentId: string) => void;
  onToggleBestComment: (productId: string, commentId: string) => void;
  onAddBanner: (title: string, image: string, content: string) => void;
  onDeleteBanner: (bannerId: string) => void;
}

export default function AdminPanel({
  products,
  categories,
  orders,
  tickets,
  banners = [],
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onAddCategory,
  onDeleteCategory,
  onUpdateOrderStatus,
  onReplyToTicket,
  onDeleteComment,
  onToggleBestComment,
  onAddBanner,
  onDeleteBanner,
}: AdminPanelProps) {
  const [adminTab, setAdminTab] = useState<'products' | 'orders' | 'support' | 'comments' | 'banners'>('products');

  // Form states for creating a banner
  const [bannerTitle, setBannerTitle] = useState('');
  const [bannerImage, setBannerImage] = useState('');
  const [bannerContent, setBannerContent] = useState('');
  const [bannerError, setBannerError] = useState('');

  // Decisions and notes for orders
  const [activeDecision, setActiveDecision] = useState<{ [orderId: string]: 'approved' | 'rejected' | null }>({});
  const [decisionNotes, setDecisionNotes] = useState<{ [orderId: string]: string }>({});
  const [previewReceipt, setPreviewReceipt] = useState<string | null>(null);

  // Products manager state
  const [editProduct, setEditProduct] = useState<SockProduct | null>(null);
  const [isAddingNew, setIsAddingNew] = useState(false);

  // New/Edit product form state
  const [prodName, setProdName] = useState('');
  const [prodPrice, setProdPrice] = useState(0);
  const [prodImage, setProdImage] = useState('');
  const [prodCategory, setProdCategory] = useState(categories[1] || 'ساق بلند');
  const [prodDesc, setProdDesc] = useState('');
  const [prodSpecs, setProdSpecs] = useState({
    material: '۸۵٪ نخ پنبه سوپر، ۱۵٪ اسپندکس',
    size: 'فری سایز',
    type: 'اسپرت',
    thickness: 'متوسط',
  });

  // Category new string create
  const [newCatString, setNewCatString] = useState('');

  // Support reply state
  const [activeTicketId, setActiveTicketId] = useState<string | null>(null);
  const [replyText, setReplyText] = useState('');

  const handleStartAddProduct = () => {
    setIsAddingNew(true);
    setEditProduct(null);
    setProdName('');
    setProdPrice(45000);
    setProdImage('https://images.unsplash.com/photo-1582966772680-860e372bb558?w=500&q=80');
    setProdCategory(categories[1] || 'ساق بلند');
    setProdDesc('جوراب باکیفیت و با دوخت صنعتی عالی.');
    setProdSpecs({
      material: '۸۵٪ نخ پنبه سوپر، ۱۵٪ اسپندکس',
      size: 'فری سایز (۳۷ تا ۴۳)',
      type: 'اسپرت',
      thickness: 'متوسط',
    });
  };

  const handleStartEditProduct = (p: SockProduct) => {
    setEditProduct(p);
    setIsAddingNew(false);
    setProdName(p.name);
    setProdPrice(p.price);
    setProdImage(p.image);
    setProdCategory(p.category);
    setProdDesc(p.description);
    setProdSpecs({ ...p.specs });
  };

  const handleSaveProductForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodName.trim() || !prodImage.trim() || prodPrice <= 0) {
      alert('لطفاً تمامی فیلدهای الزامی شامل نام، قیمت و آدرس تصویر را وارد کنید.');
      return;
    }

    if (isAddingNew) {
      const newP: SockProduct = {
        id: Date.now().toString(),
        name: prodName.trim(),
        price: Number(prodPrice),
        image: prodImage.trim(),
        category: prodCategory,
        description: prodDesc.trim(),
        specs: { ...prodSpecs },
        comments: [],
      };
      onAddProduct(newP);
      setIsAddingNew(false);
    } else if (editProduct) {
      const updatedP: SockProduct = {
        ...editProduct,
        name: prodName.trim(),
        price: Number(prodPrice),
        image: prodImage.trim(),
        category: prodCategory,
        description: prodDesc.trim(),
        specs: { ...prodSpecs },
      };
      onUpdateProduct(updatedP);
      setEditProduct(null);
    }
  };

  const handleAddNewCategory = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newCatString.trim()) return;
    if (categories.includes(newCatString.trim())) {
      alert('این دسته‌بندی از قبل تعریف شده است.');
      return;
    }
    onAddCategory(newCatString.trim());
    setNewCatString('');
  };

  const handleSendTicketReply = (ticketId: string) => {
    if (!replyText.trim()) return;
    onReplyToTicket(ticketId, replyText.trim());
    setReplyText('');
  };

  const handleCreateBanner = (e: React.FormEvent) => {
    e.preventDefault();
    if (!bannerTitle.trim() || !bannerImage.trim() || !bannerContent.trim()) {
      setBannerError('لطفاً تمامی فیلدهای بنر شامل نام، آدرس عکس و متن توضیحات را تکمیل کنید.');
      return;
    }
    onAddBanner(bannerTitle.trim(), bannerImage.trim(), bannerContent.trim());
    setBannerTitle('');
    setBannerImage('');
    setBannerContent('');
    setBannerError('');
  };

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR');
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 items-start">
      {/* Sidebar Command Tabs Selector */}
      <div className="bg-white rounded-3xl border border-slate-200 p-4 space-y-1 shadow-sm lg:col-span-1">
        <span className="text-[10px] text-slate-400 font-bold block mb-3 px-2">کنترل پنل ادمین</span>
        
        <button
          onClick={() => { setAdminTab('products'); setEditProduct(null); setIsAddingNew(false); }}
          className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
            adminTab === 'products'
              ? 'bg-orange-500 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center gap-2">
            <Tag className="h-4 w-4" />
            <span>مدیریت جوراب‌ها و دسته‌بندی</span>
          </div>
          <span className="text-[10px] bg-black/10 text-inherit px-2 py-0.5 rounded-md font-semibold">
            {products.length.toLocaleString('fa-IR')}
          </span>
        </button>

        <button
          onClick={() => setAdminTab('orders')}
          className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
            adminTab === 'orders'
              ? 'bg-orange-500 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center gap-2">
            <ClipboardList className="h-4 w-4" />
            <span>سفارشات خرید کاربران</span>
          </div>
          {orders.filter(o => o.status === 'pending').length > 0 && (
            <span className="text-[10px] bg-amber-500 text-white px-2 py-0.5 rounded-md font-bold animate-pulse">
              {orders.filter(o => o.status === 'pending').length.toLocaleString('fa-IR')} جدید
            </span>
          )}
        </button>

        <button
          onClick={() => setAdminTab('support')}
          className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
            adminTab === 'support'
              ? 'bg-orange-500 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center gap-2">
            <MessageSquare className="h-4 w-4" />
            <span>پیام‌های پشتیبانی عمومی</span>
          </div>
          <span className="text-[10px] bg-black/10 text-inherit px-2 py-0.5 rounded-md font-semibold">
            {tickets.length.toLocaleString('fa-IR')} مورد
          </span>
        </button>

        <button
          onClick={() => setAdminTab('comments')}
          className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
            adminTab === 'comments'
              ? 'bg-orange-500 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center gap-2">
            <Award className="h-4 w-4" />
            <span>مدیریت و تایید نظرات</span>
          </div>
          <span className="text-[10px] bg-black/10 text-inherit px-2 py-0.5 rounded-md font-semibold">
            {products.reduce((acc, curr) => acc + curr.comments.length, 0).toLocaleString('fa-IR')}
          </span>
        </button>

        <button
          onClick={() => setAdminTab('banners')}
          className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-bold cursor-pointer transition-all ${
            adminTab === 'banners'
              ? 'bg-orange-500 text-white shadow-sm'
              : 'text-slate-600 hover:bg-slate-50'
          }`}
        >
          <div className="flex items-center gap-2">
            <Megaphone className="h-4 w-4" />
            <span>مدیریت بنرهای تبلیغاتی</span>
          </div>
          <span className="text-[10px] bg-black/10 text-inherit px-2 py-0.5 rounded-md font-semibold">
            {banners.length.toLocaleString('fa-IR')} بنر
          </span>
        </button>
      </div>

      {/* Main Panel Content Area */}
      <div className="lg:col-span-3 space-y-6">
        
        {/* ======================= TABS 1: PRODUCTS & CATEGORY ======================= */}
        {adminTab === 'products' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
            
            {/* Products Form (Add or Edit) Column: Left Area */}
            {(isAddingNew || editProduct) ? (
              <div className="bg-white rounded-3xl border border-slate-200 p-5 md:col-span-2 shadow-sm space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200 animate-pulse-slow">
                  <h3 className="text-sm font-extrabold text-slate-800">
                    {isAddingNew ? 'اضافه کردن جوراب جدید' : `ویرایش فیلدهای: ${editProduct?.name}`}
                  </h3>
                  <button
                    onClick={() => { setIsAddingNew(false); setEditProduct(null); }}
                    className="text-xs text-orange-600 hover:bg-orange-50 px-2.5 py-1 rounded-lg cursor-pointer font-bold transition-all"
                  >
                    انصراف
                  </button>
                </div>

                <form onSubmit={handleSaveProductForm} className="space-y-4 text-xs font-semibold">
                  <div>
                    <label className="block text-slate-500 mb-1">نام و عنوان کامل جوراب (الزامی)</label>
                    <input
                      type="text"
                      required
                      placeholder="مثال: جوراب ساق بلند نخی طرح کریسمس مدل فانتزی"
                      value={prodName}
                      onChange={(e) => setProdName(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-none text-right focus:border-orange-500 focus:ring-1 focus:ring-orange-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-slate-500 mb-1">قیمت جوراب (تومان – الزامی)</label>
                      <input
                        type="number"
                        required
                        value={prodPrice}
                        onChange={(e) => setProdPrice(Number(e.target.value))}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-none text-left focus:border-orange-500 focus:ring-1 focus:ring-orange-500 font-mono"
                      />
                    </div>
                    <div>
                      <label className="block text-slate-500 mb-1">دسته‌بندی جوراب</label>
                      <select
                        value={prodCategory}
                        onChange={(e) => setProdCategory(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-none focus:border-orange-500"
                      >
                        {categories.filter(c => c !== 'همه جوراب‌ها').map((cat) => (
                           <option key={cat} value={cat}>{cat}</option>
                        ))}
                      </select>
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-500 mb-1 flex items-center gap-1">
                      <ImageIcon className="h-3.5 w-3.5 text-orange-500" />
                      <span>تصویر جوراب (آدرس اینترنتی یا آپلود مستقیم فایل)</span>
                    </label>
                    
                    <div className="space-y-2">
                      <input
                        type="text"
                        placeholder="آدرس اینترنتی تصویر (مانند: https://...)"
                        value={prodImage.startsWith('data:image') ? '' : prodImage}
                        onChange={(e) => setProdImage(e.target.value)}
                        className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2 outline-none text-left focus:border-orange-500 focus:ring-1 focus:ring-orange-500 text-xs"
                        dir="ltr"
                      />
                      
                      <div className="flex items-center gap-3 bg-slate-50 border border-dashed border-slate-200 rounded-xl p-3">
                        <label className="relative cursor-pointer bg-white border border-slate-200 hover:border-orange-500 text-slate-700 hover:text-orange-600 font-bold px-3 py-2 rounded-xl text-xs flex items-center gap-1.5 transition-all shadow-2xs">
                          <span>انتخاب و آپلود فایل تصویر</span>
                          <input
                            type="file"
                            accept="image/*"
                            className="hidden"
                            onChange={(e) => {
                              const file = e.target.files?.[0];
                              if (file) {
                                const reader = new FileReader();
                                reader.onload = () => {
                                  if (typeof reader.result === 'string') {
                                    setProdImage(reader.result);
                                  }
                                };
                                reader.readAsDataURL(file);
                              }
                            }}
                          />
                        </label>
                        
                        {prodImage ? (
                          <div className="flex items-center gap-2">
                            <img
                              src={prodImage}
                              alt="جوراب آپلود شده"
                              className="h-10 w-10 object-contain rounded-lg border border-slate-200 bg-white"
                              referrerPolicy="no-referrer"
                            />
                            <button
                              type="button"
                              onClick={() => setProdImage('')}
                              className="text-[10px] text-red-500 hover:text-red-700 font-bold hover:underline"
                            >
                              حذف تصویر
                            </button>
                          </div>
                        ) : (
                          <span className="text-[11px] text-slate-400">هیچ عکسی انتخاب نشده است</span>
                        )}
                      </div>
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-500 mb-1">توضیحات و نقد کامل جوراب</label>
                    <textarea
                      rows={3}
                      value={prodDesc}
                      onChange={(e) => setProdDesc(e.target.value)}
                      className="w-full bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500"
                    />
                  </div>

                  {/* Specifications fields details */}
                  <div className="border border-slate-200 p-3.5 rounded-2xl space-y-2 bg-slate-50/50">
                    <span className="font-bold text-slate-700 block mb-1">مشخصات فنی و کالا:</span>
                    <div className="grid grid-cols-2 gap-3">
                      <div>
                        <label className="block text-slate-400 mb-1">رشته جنس نخ</label>
                        <input
                          type="text"
                          value={prodSpecs.material}
                          onChange={(e) => setProdSpecs({ ...prodSpecs, material: e.target.value })}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 outline-none focus:border-orange-500"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">اندازه و سایز</label>
                        <input
                          type="text"
                          value={prodSpecs.size}
                          onChange={(e) => setProdSpecs({ ...prodSpecs, size: e.target.value })}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 outline-none focus:border-orange-500"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">نوع کاربری (زنانه/مردانه...)</label>
                        <input
                          type="text"
                          value={prodSpecs.type}
                          onChange={(e) => setProdSpecs({ ...prodSpecs, type: e.target.value })}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 outline-none focus:border-orange-500"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-400 mb-1">ضخامت بافت</label>
                        <input
                          type="text"
                          value={prodSpecs.thickness}
                          onChange={(e) => setProdSpecs({ ...prodSpecs, thickness: e.target.value })}
                          className="w-full bg-white border border-slate-200 rounded-lg px-2 py-1 outline-none focus:border-orange-500"
                        />
                      </div>
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full cursor-pointer rounded-xl bg-orange-500 text-white font-bold py-2.5 transition-colors hover:bg-orange-600 shadow-sm"
                  >
                    {isAddingNew ? 'افزودن و نمایش در فروشگاه' : 'ذخیره تغییرات جوراب'}
                  </button>
                </form>
              </div>
            ) : (
              /* Products List Column: Left Area */
              <div className="bg-white rounded-3xl border border-slate-200 p-5 md:col-span-2 shadow-sm space-y-4">
                <div className="flex items-center justify-between pb-3 border-b border-slate-200">
                  <h3 className="text-sm font-extrabold text-slate-800">لیست جوراب‌های موجود در فروشگاه</h3>
                  <button
                    onClick={handleStartAddProduct}
                    className="flex cursor-pointer items-center gap-1.5 bg-orange-500 hover:bg-orange-600 text-white text-xs font-bold px-4 py-2 rounded-xl transition-colors shadow-sm"
                  >
                    <Plus className="h-3.5 w-3.5" />
                    <span>افزودن جوراب جدید</span>
                  </button>
                </div>

                <div className="divide-y divide-slate-100 max-h-[500px] overflow-y-auto pr-1">
                  {products.map((p) => (
                    <div key={p.id} className="py-3.5 flex items-center justify-between gap-3 hover:bg-slate-50/50 px-2 rounded-xl transition-all">
                      <div className="flex items-center gap-3">
                        <img
                          src={p.image}
                          alt={p.name}
                          referrerPolicy="no-referrer"
                          className="h-10 w-10 object-contain rounded-xl border border-slate-200 p-1 bg-slate-50 shrink-0"
                        />
                        <div>
                          <span className="text-xs font-bold text-slate-888 block line-clamp-1">{p.name}</span>
                          <span className="text-[10px] text-slate-400 font-sans block mt-0.5">
                            دسته‌بندی: {p.category} | قیمت: {formatPrice(p.price)} تومان
                          </span>
                        </div>
                      </div>

                      <div className="flex items-center gap-2 shrink-0">
                        <button
                          onClick={() => handleStartEditProduct(p)}
                          className="p-1 px-2.5 border border-slate-200 rounded-lg bg-white hover:bg-slate-50 text-slate-500 cursor-pointer text-[10px] font-bold flex items-center gap-1 transition-all"
                          title="ویرایش"
                        >
                          <Edit2 className="h-3 w-3 text-slate-400" />
                          <span>ویرایش</span>
                        </button>
                        <button
                          onClick={() => {
                            if (confirm('آیا از حذف این جوراب اطمینان دارید؟')) onDeleteProduct(p.id);
                          }}
                          className="p-1 px-2.5 border border-orange-100 rounded-lg bg-orange-50/50 hover:bg-orange-100 text-orange-600 cursor-pointer text-[10px] font-bold flex items-center gap-1 transition-all"
                          title="حذف"
                        >
                          <Trash2 className="h-3 w-3 text-orange-500" />
                          <span>حذف</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Right Column: Manage Categories */}
            <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4 md:col-span-1">
              <h3 className="text-sm font-extrabold text-slate-800 pb-3 border-b border-slate-200">ویرایش دسته‌بندی‌ها</h3>
              
              {/* Add form */}
              <form onSubmit={handleAddNewCategory} className="space-y-2">
                <input
                  type="text"
                  required
                  placeholder="مثال: جوراب فانتزی دخترانه"
                  value={newCatString}
                  onChange={(e) => setNewCatString(e.target.value)}
                  className="w-full text-xs font-semibold rounded-xl bg-slate-50 border border-slate-200 p-2.5 outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500"
                />
                <button
                  type="submit"
                  className="w-full cursor-pointer rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs py-2 transition-all flex items-center justify-center gap-1 border border-slate-200"
                >
                  <Plus className="h-3.5 w-3.5 text-slate-500" />
                  <span>افزودن دسته‌بندی جدید</span>
                </button>
              </form>

              {/* List */}
              <div className="space-y-1.5 max-h-[250px] overflow-y-auto pr-1">
                {categories.map((cat) => (
                  <div key={cat} className="flex items-center justify-between p-2.5 rounded-xl bg-slate-50 text-[11px] font-bold border border-slate-200/50">
                    <span className="text-slate-700">{cat}</span>
                    {cat !== 'همه جوراب‌ها' && categories.length > 2 && (
                      <button
                        onClick={() => {
                          if (confirm(`تمام جوراب‌های مربوط به دسته‌بندی "${cat}" بدون دسته‌بندی خواهند شد. ادامه؟`)) {
                            onDeleteCategory(cat);
                          }
                        }}
                        className="text-orange-500 hover:bg-orange-50 p-1.5 rounded-lg cursor-pointer transition-all"
                        title="حذف دسته‌بندی"
                      >
                        <Trash2 className="h-3 w-3" />
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>

          </div>
        )}

        {/* ======================= TABS 2: ORDERS MANAGEMENT ======================= */}
        {adminTab === 'orders' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4">
            <h3 className="text-sm font-extrabold text-slate-800 pb-3 border-b border-slate-200 flex items-center justify-between">
              <span>درخواست‌های واریزی و فاکتورها</span>
              <span className="text-xs bg-slate-100 text-slate-500 font-sans px-2.5 py-0.5 rounded-full">
                {orders.length.toLocaleString('fa-IR')} خرید ثبت شده
              </span>
            </h3>

            {orders.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-10">تا کنون سفارشی از طرف خریداران ثبت نشده است.</p>
            ) : (
              <div className="space-y-4">
                {orders.map((order) => (
                  <div key={order.id} className="border border-slate-200 rounded-3xl overflow-hidden shadow-sm bg-slate-50/20">
                    {/* Top Info */}
                    <div className="bg-slate-100/50 border-b border-slate-200 px-4 py-3 flex flex-wrap items-center justify-between gap-3 text-xs">
                      <div className="font-sans font-bold text-slate-600 flex items-center gap-x-3 gap-y-1 flex-wrap">
                        <span className="bg-white px-2 py-0.5 border border-slate-200 rounded-lg text-slate-800">
                          کد سفارش: #{order.id}
                        </span>
                        <span>تاریخ: {order.date}</span>
                        <span className="text-slate-800">
                          خریدار: <strong>{order.userName}</strong>
                        </span>
                      </div>

                      {/* Status */}
                      <div>
                        {order.status === 'approved' ? (
                          <span className="text-emerald-700 bg-emerald-50 border border-emerald-200 px-2.5 py-1 rounded-full text-[10px] font-bold">✓ تراکنش تایید شده</span>
                        ) : order.status === 'rejected' ? (
                          <span className="text-orange-700 bg-orange-50 border border-orange-200 px-2.5 py-1 rounded-full text-[10px] font-bold">✗ تراکنش رد شده</span>
                        ) : (
                          <span className="text-amber-700 bg-amber-50 border border-amber-200 px-2.5 py-1 rounded-full text-[10px] font-bold animate-pulse">در انتظار تایید ادمین</span>
                        )}
                      </div>
                    </div>

                    {/* Products details */}
                    <div className="p-4 sm:p-5 space-y-3">
                      <div className="divide-y divide-slate-100">
                        {order.items.map((it) => (
                          <div key={it.productId} className="py-2.5 flex items-center justify-between text-xs font-semibold">
                            <div className="flex items-center gap-2">
                              <img src={it.image} alt={it.name} className="h-8 w-8 object-contain" referrerPolicy="no-referrer" />
                              <span className="text-slate-800">{it.name} <strong className="text-orange-600">({it.quantity.toLocaleString('fa-IR')} عدد)</strong></span>
                            </div>
                            <span className="text-slate-500 font-sans">{formatPrice(it.price * it.quantity)} تومان</span>
                          </div>
                        ))}
                      </div>

                      <div className="border-t border-slate-100 pt-3 flex flex-wrap gap-3 items-center justify-between text-xs">
                        <div className="text-slate-500 font-sans">
                          شماره پیگیری واریز: <strong className="text-slate-800 bg-white border border-slate-200 px-2 py-0.5 rounded-lg font-bold">{order.refNumber}</strong>
                        </div>
                        <div className="flex items-center gap-1">
                          <span className="text-slate-500 font-bold">کل مبلغ پرداخت شده به کارت:</span>
                          <strong className="text-sm font-black text-slate-800 underline bg-white border border-slate-205 px-2.5 py-0.5 rounded-lg">{formatPrice(order.totalPrice)}</strong>
                          <span className="text-slate-500 text-[10px]">تومان</span>
                        </div>
                      </div>

                      {/* Delivery Details */}
                      {(order.userPhone || order.postalCode || order.address) && (
                        <div className="bg-orange-50/20 border border-orange-100 rounded-2xl p-4 mt-3 text-xs space-y-2">
                          <p className="font-extrabold text-orange-950 flex items-center gap-1">
                            <span>🚛 مشخصات و آدرس ثبت شده برای تحویل پستی سفارش:</span>
                          </p>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-600">
                            {order.userPhone && (
                              <div>
                                <span className="font-semibold text-slate-400 ml-1">تلفن هماهنگی:</span>
                                <span className="font-sans font-bold text-slate-700">{order.userPhone}</span>
                              </div>
                            )}
                            {order.postalCode && (
                              <div>
                                <span className="font-semibold text-slate-400 ml-1">کد پستی ۱۰ رقمی:</span>
                                <span className="font-sans font-bold text-slate-700">{order.postalCode}</span>
                              </div>
                            )}
                          </div>
                          {order.address && (
                            <div className="pt-2 border-t border-slate-200 text-slate-700">
                              <span className="font-semibold text-slate-400 ml-1">آدرس پستی دقیق گیرنده:</span>
                              <span className="font-bold text-slate-900">{order.address}</span>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Receipt Image Display */}
                      {order.receiptImage && (
                        <div className="bg-slate-100/50 border border-slate-200/80 rounded-2xl p-4 mt-3 text-xs space-y-2 text-right" dir="rtl">
                          <p className="font-extrabold text-slate-850 flex items-center justify-start gap-1">
                            <ImageIcon className="h-4 w-4 text-orange-500" />
                            <span>تصویر فیش/رسید انتقال وجه خریدار:</span>
                          </p>
                          <div className="flex flex-col sm:flex-row gap-4 items-center sm:items-start">
                            <div 
                              onClick={() => setPreviewReceipt(order.receiptImage || null)}
                              className="relative group overflow-hidden rounded-xl border border-slate-250 w-32 bg-white cursor-pointer shadow-xs hover:border-orange-500 transition-all shrink-0"
                            >
                              <img
                                src={order.receiptImage}
                                alt="رسید پرداختی کاربر"
                                className="object-cover h-24 w-full group-hover:scale-105 transition-transform duration-300"
                              />
                              <div className="absolute inset-0 bg-slate-900/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <span className="bg-white/95 text-[9px] font-extrabold px-2 py-1 rounded-md text-slate-900 shadow-sm">بزرگ‌نمایی</span>
                              </div>
                            </div>
                            <div className="space-y-1.5 text-slate-500 font-medium">
                              <p className="text-[11px] text-slate-700 font-bold">مبلغ نهایی سفارش را با فیش بالا مطابقت دهید.</p>
                              <p className="text-[10px] text-slate-400 leading-relaxed">برای بزرگ‌نمایی باکیفیت و خواندن همه‌ی جزییات تراکنش و تطابق با کارهای انتخابی، روی تصویر کلیک کنید.</p>
                              <button
                                type="button"
                                onClick={() => setPreviewReceipt(order.receiptImage || null)}
                                className="font-sans inline-flex items-center gap-1 text-[10px] bg-orange-50 hover:bg-orange-600 text-orange-600 hover:text-white border border-orange-200 px-3 py-1.5 rounded-xl font-bold transition-all mt-1 cursor-pointer"
                              >
                                <span>باز کردن بزرگ‌نمایی رسید</span>
                              </button>
                            </div>
                          </div>
                        </div>
                      )}

                      {/* Display existing adminNotes for completed orders */}
                      {order.adminNotes && (
                        <div className="bg-slate-100/80 border border-slate-200/60 rounded-2xl p-3.5 text-xs text-slate-700 space-y-1 mt-3">
                          <span className="font-bold text-slate-400 block pb-1">پیام ارسال شده به کاربر:</span>
                          <p className="font-semibold bg-white p-2 rounded-xl border border-slate-200/50">{order.adminNotes}</p>
                        </div>
                      )}

                      {/* Decission buttons option */}
                      {order.status === 'pending' && (
                        <div className="mt-4 pt-3 border-t border-slate-200/65">
                          {!activeDecision[order.id] ? (
                            <div className="flex justify-end gap-3">
                              <button
                                onClick={() => {
                                  setActiveDecision(prev => ({ ...prev, [order.id]: 'approved' }));
                                  setDecisionNotes(prev => ({
                                    ...prev,
                                    [order.id]: 'سفارش شما با موفقیت تایید شد. طبق هماهنگی، بسته به شرکت پست تحویل داده شده و به زودی (۳ الی ۵ روز کاری) به دست شما خواهد رسید.'
                                  }));
                                }}
                                className="bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors shadow-xs animate-fade-in"
                              >
                                <Check className="h-4 w-4" />
                                <span>تایید واریزی و فاکتور</span>
                              </button>
                              <button
                                onClick={() => {
                                  setActiveDecision(prev => ({ ...prev, [order.id]: 'rejected' }));
                                  setDecisionNotes(prev => ({
                                    ...prev,
                                    [order.id]: 'کد پیگیری یا مبلغ تراکنش پرداخت شده نامعتبر تشخیص داده شد. لطفاً تصویر رسید خود را کنترل کرده یا مجدداً سفارش را تایید کنید.'
                                  }));
                                }}
                                className="bg-orange-50 hover:bg-orange-100 text-orange-600 border border-orange-200 font-bold text-xs px-4 py-2.5 rounded-xl flex items-center gap-1.5 cursor-pointer transition-colors"
                              >
                                <X className="h-4 w-4" />
                                <span>رد کردن فاکتور (عدم واریز)</span>
                              </button>
                            </div>
                          ) : (
                            <div className="bg-white border border-slate-200 rounded-2xl p-4 space-y-3 shadow-xs">
                              <p className="text-xs font-bold text-slate-700 flex items-center gap-1">
                                <span className={`h-2.5 w-2.5 rounded-full ${activeDecision[order.id] === 'approved' ? 'bg-emerald-500' : 'bg-orange-500'}`} />
                                <span>
                                  {activeDecision[order.id] === 'approved' 
                                    ? 'اطلاعات پست و زمان تقریبی تحویل را بنویسید تا به مشتری اطلاع داده شود:' 
                                    : 'علت و دلیل رد فاکتور خریدار را ذکر کنید:'}
                                </span>
                              </p>
                              
                              <textarea
                                rows={3}
                                required
                                value={decisionNotes[order.id] || ''}
                                onChange={(e) => setDecisionNotes(prev => ({ ...prev, [order.id]: e.target.value }))}
                                className="w-full text-xs font-semibold rounded-xl border border-slate-200 px-4 py-2.5 text-right text-slate-800 outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 resize-none bg-slate-50/50 font-sans"
                                placeholder={activeDecision[order.id] === 'approved' 
                                  ? 'مثال: بسته شما با پست پیشتاز ارسال گردید. زمان تقریبی تحویل ۴۸ ساعت آینده...' 
                                  : 'علت عدم تایید تراکنش را بنویسید...'}
                              />

                              <div className="flex justify-end gap-2.5">
                                <button
                                  onClick={() => {
                                    onUpdateOrderStatus(order.id, activeDecision[order.id]!, decisionNotes[order.id]);
                                    setActiveDecision(prev => ({ ...prev, [order.id]: null }));
                                  }}
                                  className={`cursor-pointer font-bold text-xs px-4.5 py-2 rounded-xl text-white transition-colors shadow-xs ${
                                    activeDecision[order.id] === 'approved' 
                                      ? 'bg-emerald-600 hover:bg-emerald-700' 
                                      : 'bg-orange-600 hover:bg-orange-700'
                                  }`}
                                >
                                  ثبت تصمیم نهایی
                                </button>
                                <button
                                  onClick={() => setActiveDecision(prev => ({ ...prev, [order.id]: null }))}
                                  className="cursor-pointer font-bold text-xs px-4 py-2 text-slate-500 hover:bg-slate-100 rounded-xl transition-colors border border-slate-200"
                                >
                                  انصراف
                                </button>
                              </div>
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {/* ======================= TABS 3: SUPPORT MESSAGES ======================= */}
        {adminTab === 'support' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4">
            <h3 className="text-sm font-extrabold text-slate-800 pb-3 border-b border-slate-200">پیام‌های کاربران پشتیبانی</h3>
            
            {tickets.length === 0 ? (
              <p className="text-xs text-slate-400 text-center py-10">هیچ تیکت فعال یا تیکتی ثبت نشده است.</p>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {/* Tickets list selector */}
                <div className="border border-slate-200 bg-slate-50/20 rounded-2xl divide-y divide-slate-100 overflow-hidden md:col-span-1">
                  {tickets.map((t) => {
                    const lastMsg = t.messages[t.messages.length - 1];
                    const isLastMsgAdmin = lastMsg?.sender === 'admin';
                    return (
                      <button
                        key={t.id}
                        onClick={() => { setActiveTicketId(t.id); setReplyText(''); }}
                        className={`w-full text-right p-3.5 hover:bg-slate-50 flex flex-col cursor-pointer transition-colors ${
                          activeTicketId === t.id ? 'bg-orange-50/40 border-r-4 border-orange-500' : ''
                        }`}
                      >
                        <span className="text-xs font-bold text-slate-800 block truncate">{t.userName}</span>
                        <span className="text-[10px] text-slate-400 block mt-1">{t.userPhone}</span>
                        {lastMsg && (
                          <span className={`text-[10px] truncate block mt-2 ${isLastMsgAdmin ? 'text-slate-400' : 'text-orange-600 font-bold'}`}>
                            {isLastMsgAdmin ? 'پاسخ داده شده' : `جدید: ${lastMsg.text}`}
                          </span>
                        )}
                      </button>
                    );
                  })}
                </div>

                {/* Ticket conversation history/reply */}
                <div className="border border-slate-200 rounded-2xl p-4 md:col-span-2 flex flex-col justify-between h-[450px] bg-slate-50/30">
                  {activeTicketId ? (
                    (() => {
                      const activeTicket = tickets.find(t => t.id === activeTicketId);
                      if (!activeTicket) return null;
                      return (
                        <>
                          {/* Chat Area inside ticket */}
                          <div className="flex-1 overflow-y-auto space-y-3 mb-4 pr-1">
                            {activeTicket.messages.map((m) => (
                              <div
                                key={m.id}
                                className={`flex flex-col max-w-[85%] ${m.sender === 'admin' ? 'mr-auto items-start' : 'ml-auto items-end'}`}
                              >
                                <div
                                  className={`rounded-xl px-3 py-2 text-xs leading-relaxed ${
                                    m.sender === 'admin'
                                      ? 'bg-orange-500 text-white rounded-tr-xs shadow-xs'
                                      : 'bg-white border border-slate-200 text-slate-800 rounded-tl-xs shadow-xs'
                                  }`}
                                >
                                  {m.text}
                                </div>
                                <span className="text-[9px] text-slate-400 font-sans mt-0.5">{m.timestamp}</span>
                              </div>
                            ))}
                          </div>

                          {/* Reply Box input */}
                          <div className="border-t border-slate-100 pt-3 flex gap-2">
                            <input
                              type="text"
                              placeholder="پاسخ ادمین برای این کاربر..."
                              value={replyText}
                              onChange={(e) => setReplyText(e.target.value)}
                              className="flex-1 rounded-xl bg-white border border-slate-200 text-xs px-3 py-2 outline-none focus:border-orange-500"
                            />
                            <button
                              onClick={() => handleSendTicketReply(activeTicket.id)}
                              className="bg-orange-500 hover:bg-orange-600 text-white font-bold text-xs px-4 py-2 rounded-xl cursor-pointer shadow-sm transition-colors"
                            >
                              ارسال پاسخ
                            </button>
                          </div>
                        </>
                      );
                    })()
                  ) : (
                    <div className="h-full flex flex-col items-center justify-center text-center text-slate-400">
                      <HeartHandshake className="h-10 w-10 text-slate-350 mb-2 animate-pulse" />
                      <p className="text-xs max-w-xs leading-relaxed">یک تیکت را از منوی سمت راست جهت مشاهده مکالمات و پاسخگویی آنلاین انتخاب کنید.</p>
                    </div>
                  )}
                </div>
              </div>
            )}
          </div>
        )}

        {/* ======================= TABS 4: COMMENTS MODERATION ======================= */}
        {adminTab === 'comments' && (
          <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4">
            <h3 className="text-sm font-extrabold text-slate-800 pb-3 border-b border-slate-200">مدیریت و فیلترینگ نظرات کل جوراب‌ها</h3>
            
            <div className="space-y-4">
              {products.flatMap(p => p.comments.map(c => ({ product: p, comment: c }))).length === 0 ? (
                <p className="text-xs text-slate-400 text-center py-10">هیچ نظری روی هیچ جورابی ثبت نشده است.</p>
              ) : (
                products.flatMap(p => p.comments.map(c => ({ product: p, comment: c }))).map(({ product, comment }) => (
                  <div
                    key={comment.id}
                    className={`p-4 rounded-2xl border flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 transition-all ${
                      comment.isFeatured
                        ? 'bg-amber-50/50 border-amber-200 shadow-xs'
                        : 'bg-slate-50/40 border-slate-200 shadow-xs'
                    }`}
                  >
                    <div className="space-y-1.5 flex-1 min-w-0">
                      <span className="text-[10px] text-slate-400 bg-white border border-slate-205 p-1 px-2.5 rounded-lg font-bold block shrink-0 max-w-fit shadow-xs">
                        روی کالا: {product.name}
                      </span>
                      <div className="flex items-center gap-2">
                        <strong className="text-xs text-slate-700">{comment.userName}</strong>
                        <div className="flex gap-0.5" dir="ltr">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`h-3 w-3 ${
                                i < comment.rating ? 'fill-amber-400 text-amber-400' : 'text-slate-200'
                              }`}
                            />
                          ))}
                        </div>
                        {comment.isFeatured && (
                          <span className="text-[9px] font-bold text-amber-700 bg-amber-100 px-1.5 py-0.5 rounded flex items-center gap-0.5">
                            <Award className="h-3 w-3" />
                            برترین
                          </span>
                        )}
                      </div>
                      <p className="text-xs text-slate-600 leading-relaxed pr-1 mt-1">{comment.text}</p>
                    </div>

                    <div className="flex gap-2 shrink-0 self-end sm:self-center">
                      <button
                        onClick={() => onToggleBestComment(product.id, comment.id)}
                        className={`text-[10px] font-bold px-3 py-2 rounded-xl border cursor-pointer flex items-center gap-1 transition-all ${
                          comment.isFeatured
                            ? 'bg-amber-100 hover:bg-amber-200 border-amber-200 text-amber-800'
                            : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-600'
                        }`}
                      >
                        <Award className="h-3.5 w-3.5" />
                        <span>{comment.isFeatured ? 'حذف از صدر برترین‌ها' : 'انتخاب به برترین نظر'}</span>
                      </button>

                      <button
                        onClick={() => onDeleteComment(product.id, comment.id)}
                        className="text-[10px] font-bold text-orange-600 bg-orange-50 hover:bg-orange-100 border border-orange-200 px-3 py-2 rounded-xl cursor-pointer flex items-center gap-1 transition-all"
                      >
                        <Trash2 className="h-3.5 w-3.5" />
                        <span>حذف نظر</span>
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        )}

        {/* ===================== TABS 5: BANNERS MANAGEMENT ===================== */}
        {adminTab === 'banners' && (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Create Banner Form */}
            <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4 lg:col-span-1 self-start animate-fade-in text-right">
              <h3 className="text-sm font-extrabold text-slate-800 pb-3 border-b border-slate-200 flex items-center justify-start gap-1.5 direction-rtl">
                <Plus className="h-4.5 w-4.5 text-orange-500" />
                <span>ساخت بنر تبلیغاتی جدید</span>
              </h3>

              {bannerError && (
                <div className="rounded-xl bg-orange-50 p-2.5 text-xs text-orange-700 border border-orange-100 text-right">
                  <span>{bannerError}</span>
                </div>
              )}

              <form onSubmit={handleCreateBanner} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1.5 text-right">
                    عنوان بنر / نام بنر:
                  </label>
                  <input
                    type="text"
                    required
                    placeholder="مثال: حراج آخر فصل جوراب‌های پشمی"
                    value={bannerTitle}
                    onChange={(e) => { setBannerTitle(e.target.value); setBannerError(''); }}
                    className="w-full text-xs font-semibold rounded-xl bg-slate-50 border border-slate-200 px-3 py-2.5 outline-none focus:border-orange-500 focus:bg-white focus:ring-1 focus:ring-orange-500 text-right"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1.5 text-right">
                    آدرس اینترنتی تصویر بنر:
                  </label>
                  <input
                    type="url"
                    required
                    placeholder="https://images.unsplash.com/photo-..."
                    value={bannerImage}
                    onChange={(e) => { setBannerImage(e.target.value); setBannerError(''); }}
                    className="w-full text-xs font-semibold rounded-xl bg-slate-50 border border-slate-200 px-3 py-2.5 outline-none focus:border-orange-500 focus:bg-white focus:ring-1 focus:ring-orange-500 text-left"
                    dir="ltr"
                  />
                  <span className="text-[10px] text-slate-400 mt-1 block text-right">
                    نکته: می‌توانید یک آدرس عکس از Unsplash یا اینترنت بازنشانی کنید
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-600 mb-1.5 text-right">
                    متن توضیحات و محتوای بنر:
                  </label>
                  <textarea
                    required
                    rows={6}
                    placeholder="خیلی کوتاه یا بلند. کاربر پس از انتخاب روی بنر، این متن در رابطه با بنر را خواهد دید..."
                    value={bannerContent}
                    onChange={(e) => { setBannerContent(e.target.value); setBannerError(''); }}
                    className="w-full text-xs font-semibold rounded-xl bg-slate-50 border border-slate-200 px-3 py-2.5 outline-none focus:border-orange-500 focus:bg-white focus:ring-1 focus:ring-orange-500 text-right resize-none font-sans leading-relaxed"
                  />
                </div>

                <button
                  type="submit"
                  className="w-full cursor-pointer rounded-xl bg-orange-500 hover:bg-orange-600 py-3 font-semibold text-white transition-all text-xs shadow-sm flex items-center justify-center gap-1.5"
                >
                  <Plus className="h-4.5 w-4.5" />
                  <span>ایجاد و فعال‌سازی روی سایت</span>
                </button>
              </form>
            </div>

            {/* Banners List */}
            <div className="bg-white rounded-3xl border border-slate-200 p-5 shadow-sm space-y-4 lg:col-span-2 text-right">
              <h3 className="text-sm font-extrabold text-slate-800 pb-3 border-b border-slate-200 flex items-center justify-between">
                <span>بنرهای فعال فروشگاه و اسلایدرها</span>
                <span className="text-[11px] text-slate-400 bg-slate-50 border border-slate-100 px-2 py-0.5 rounded-lg">
                  {banners.length.toLocaleString('fa-IR')} بنر فعال
                </span>
              </h3>

              {banners.length === 0 ? (
                <div className="text-center py-16">
                  <Megaphone className="h-10 w-10 text-slate-300 mx-auto mb-2" />
                  <p className="text-xs text-slate-400">هیچ بنر تبلیغاتی فعالی وجود ندارد.</p>
                </div>
              ) : (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {banners.map((b) => (
                    <div key={b.id} className="border border-slate-200 rounded-2xl overflow-hidden flex flex-col justify-between bg-slate-50/20 shadow-xs hover:shadow-sm transition-all text-right">
                      <div className="relative h-32 w-full bg-slate-200 overflow-hidden">
                        <img 
                          src={b.image} 
                          alt={b.title} 
                          className="h-full w-full object-cover"
                          onError={(e) => {
                            (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1582966772680-860e372bb558?w=500&q=80';
                          }}
                        />
                        <span className="absolute top-2.5 right-2.5 bg-slate-900/75 backdrop-blur-md text-[10px] text-white px-2 py-0.5 rounded-md font-bold">
                          آیدی: {b.id}
                        </span>
                      </div>

                      <div className="p-3.5 space-y-2">
                        <h4 className="text-xs font-black text-slate-800 truncate">{b.title}</h4>
                        <p className="text-[10px] text-slate-500 line-clamp-3 leading-relaxed text-right">
                          {b.content}
                        </p>
                      </div>

                      <div className="p-3 border-t border-slate-200/50 bg-slate-50/50 flex justify-end">
                        <button
                          onClick={() => onDeleteBanner(b.id)}
                          className="text-[10px] font-bold text-orange-600 hover:text-white bg-orange-50 hover:bg-orange-600 border border-orange-200 px-2.5 py-1.5 rounded-lg cursor-pointer transition-all flex items-center gap-1 shadow-2xs"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                          <span>حذف بنر</span>
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>
        )}

      </div>

      {/* Full-width Modal View overlay for checking receipts */}
      {previewReceipt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-955/85 backdrop-blur-md animate-fade-in text-right" dir="rtl">
          <div className="bg-white w-full max-w-md rounded-3xl overflow-hidden shadow-2xl border border-slate-100 flex flex-col max-h-[90vh]">
            <div className="p-4 bg-slate-50 border-b border-slate-150 flex items-center justify-between shrink-0">
              <span className="text-xs font-black text-slate-850">بررسی جزییات فیش پرداخت خریدار</span>
              <button
                onClick={() => setPreviewReceipt(null)}
                className="h-8 w-8 rounded-xl hover:bg-slate-200 border border-slate-200/60 flex items-center justify-center text-slate-500 hover:text-slate-800 cursor-pointer transition-colors font-extrabold text-xs font-sans"
              >
                ✕
              </button>
            </div>
            
            <div className="p-4 overflow-y-auto flex-1 flex justify-center bg-slate-100 items-center">
              <img
                src={previewReceipt}
                alt="رسید بزرگ‌نمایی شده"
                className="max-h-[55vh] max-w-full object-contain rounded-xl border border-slate-200 bg-white"
              />
            </div>

            <div className="p-3 bg-slate-50 border-t border-slate-150 flex justify-between gap-2.5">
              <a
                href={previewReceipt}
                download="receipt-admin-inspect.png"
                className="cursor-pointer bg-slate-200 hover:bg-slate-300 text-slate-700 font-bold text-[10px] sm:text-xs px-4 py-2 rounded-xl transition-colors flex items-center"
              >
                دانلود مستقیم فایل
              </a>
              <button
                onClick={() => setPreviewReceipt(null)}
                className="cursor-pointer bg-orange-500 hover:bg-orange-600 text-white font-extrabold text-[10px] sm:text-xs px-5 py-2 rounded-xl transition-colors"
              >
                بازگشت به سفارشات
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
