import React, { useState } from 'react';
import { Search, ShoppingCart, LogOut, User as UserIcon, Settings, MessageSquare, Tag, Key } from 'lucide-react';
import { UserSession } from '../types';

interface NavbarProps {
  session: UserSession;
  cartCount: number;
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  onLogout: () => void;
  onOpenCart: () => void;
  activeTab: 'shop' | 'orders' | 'support' | 'admin';
  setActiveTab: (tab: 'shop' | 'orders' | 'support' | 'admin') => void;
  hasNewSupportReplies?: boolean;
  onBecomeAdmin?: () => void;
}

export default function Navbar({
  session,
  cartCount,
  searchQuery,
  setSearchQuery,
  onLogout,
  onOpenCart,
  activeTab,
  setActiveTab,
  hasNewSupportReplies = false,
  onBecomeAdmin,
}: NavbarProps) {
  const [showAdminInput, setShowAdminInput] = useState(false);
  const [adminCode, setAdminCode] = useState('');
  const [adminCodeError, setAdminCodeError] = useState(false);

  const handleAdminCodeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/\s/g, '');
    setAdminCode(val);
    
    if (val === '13911400') {
      if (onBecomeAdmin) {
        onBecomeAdmin();
      }
      setShowAdminInput(false);
      setAdminCode('');
      setAdminCodeError(false);
    } else if (val.length >= 8) {
      setAdminCodeError(true);
      setTimeout(() => setAdminCodeError(false), 2000);
    }
  };

  return (
    <header className="sticky top-0 z-40 bg-white border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16 gap-4">
          
          {/* Right section: Logo, Admin trigger & Search */}
          <div className="flex items-center gap-6 flex-1">
            {/* Logo */}
            <div 
              onClick={() => setActiveTab('shop')} 
              className="flex items-center gap-2.5 cursor-pointer select-none"
            >
              <div className="bg-orange-500 text-white p-2.5 rounded-xl flex items-center justify-center shadow-xs">
                <Tag className="h-5 w-5 transform rotate-45" />
              </div>
              <span className="text-xl font-black text-slate-900 tracking-tight hidden sm:inline">sockuraaa</span>
            </div>

            {/* Admin Key Code Input on Top Right */}
            {!session.isAdmin && (
              <div className="flex items-center gap-1.5 transition-all duration-300">
                {showAdminInput ? (
                  <div className="flex items-center gap-1.5 h-10 animate-fade-in bg-slate-50 border border-slate-100 pl-2 pr-1 rounded-2xl">
                    <input
                      type="text"
                      maxLength={8}
                      placeholder="کد ۸ رقمی..."
                      value={adminCode}
                      onChange={handleAdminCodeChange}
                      className={`h-7 w-20 bg-white border text-[11px] text-center font-bold tracking-widest rounded-lg outline-none focus:ring-2 focus:ring-orange-100 transition-all ${
                        adminCodeError 
                          ? 'border-red-500 text-red-600 focus:border-red-500' 
                          : 'border-slate-200 focus:border-orange-500 text-slate-800'
                      }`}
                      autoFocus
                    />
                    <button 
                      onClick={() => { setShowAdminInput(false); setAdminCode(''); }}
                      className="text-[10px] text-slate-400 hover:text-slate-600 px-1 font-bold cursor-pointer"
                    >
                      لغو
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => setShowAdminInput(true)}
                    className="p-2 bg-slate-50 hover:bg-orange-50 text-slate-400 hover:text-orange-500 border border-slate-200/40 rounded-xl transition-all cursor-pointer flex items-center gap-1 text-[10px] font-bold shrink-0"
                    title="ورود به پنل مدیریت با وارد کردن کد"
                  >
                    <Key className="h-3.5 w-3.5" />
                    <span className="hidden sm:inline">ورود همکار</span>
                  </button>
                )}
              </div>
            )}

            {/* Search Input */}
            <div className="relative flex-1 max-w-sm">
              <span className="absolute inset-y-0 right-3.5 flex items-center pointer-events-none text-slate-400">
                <Search className="h-4 w-4" />
              </span>
              <input
                type="text"
                placeholder="جستجو در بین جوراب‌ها..."
                value={searchQuery}
                onChange={(e) => {
                  setSearchQuery(e.target.value);
                  if (activeTab !== 'shop') setActiveTab('shop');
                }}
                className="w-full bg-slate-100 rounded-xl py-2 pr-10 pl-4 text-xs sm:text-sm text-slate-800 placeholder-slate-400 outline-none transition-all duration-200 focus:bg-white focus:ring-2 focus:ring-orange-500 border border-transparent focus:border-orange-500"
              />
            </div>
          </div>

          {/* Left section: Tabs, Cart, User panel */}
          <div className="flex items-center gap-2 sm:gap-4 shrink-0">
            {/* Tabs */}
            <div className="flex items-center bg-slate-100 p-1 rounded-xl text-xs sm:text-sm font-medium">
              <button
                onClick={() => setActiveTab('shop')}
                className={`px-3 py-1.5 rounded-lg cursor-pointer transition-all ${
                  activeTab === 'shop' 
                    ? 'bg-white text-orange-600 shadow-xs font-semibold' 
                    : 'text-slate-500 hover:text-slate-900'
                }`}
              >
                فروشگاه
              </button>

              {session.isAdmin ? (
                <button
                  onClick={() => setActiveTab('admin')}
                  className={`px-3 py-1.5 rounded-lg cursor-pointer flex items-center gap-1 transition-all ${
                    activeTab === 'admin' 
                      ? 'bg-orange-500 text-white shadow-xs font-semibold' 
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                >
                  <Settings className="h-3.5 w-3.5" />
                  <span>مدیریت ادمین</span>
                </button>
              ) : (
                <>
                  <button
                    onClick={() => setActiveTab('orders')}
                    className={`px-3 py-1.5 rounded-lg cursor-pointer transition-all ${
                      activeTab === 'orders' 
                        ? 'bg-white text-orange-600 shadow-xs font-semibold' 
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    خریدهای من
                  </button>

                  <button
                    onClick={() => setActiveTab('support')}
                    className={`px-3 py-1.5 rounded-lg cursor-pointer flex items-center gap-1 transition-all relative ${
                      activeTab === 'support' 
                        ? 'bg-white text-orange-600 shadow-xs font-semibold' 
                        : 'text-slate-500 hover:text-slate-900'
                    }`}
                  >
                    <MessageSquare className="h-3.5 w-3.5" />
                    <span>پشتیبانی</span>
                    {hasNewSupportReplies && (
                      <span className="absolute -top-1 -left-1 flex h-2.5 w-2.5 rounded-full bg-orange-500">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-orange-400 opacity-75"></span>
                      </span>
                    )}
                  </button>
                </>
              )}
            </div>

            {/* Shopping Cart button - only for customers */}
            {!session.isAdmin && (
              <button
                onClick={onOpenCart}
                className="relative bg-slate-100 hover:bg-slate-200 p-2.5 rounded-xl cursor-pointer transition-all group"
                aria-label="سبد خرید"
              >
                <ShoppingCart className="h-5 w-5 text-slate-700 group-hover:text-orange-500" />
                {cartCount > 0 && (
                  <span className="absolute -top-1 -left-1 bg-orange-500 text-white text-[10px] font-bold h-5 w-5 flex items-center justify-center rounded-full border-2 border-white animate-bounce-short">
                    {cartCount}
                  </span>
                )}
              </button>
            )}

            {/* User Session Detail */}
            <div className="hidden md:flex items-center gap-2 border-r border-slate-100 pr-4">
              <div className="text-right">
                <div className="text-sm font-semibold truncate max-w-[120px]">{session.name}</div>
                <div className="text-[10px] text-slate-400">
                  {session.isAdmin ? (
                    <span className="bg-orange-50 text-orange-600 px-1.5 py-0.5 rounded font-bold">مدیر ارشد</span>
                  ) : (
                    <span>مشتری</span>
                  )}
                </div>
              </div>
              <div className="h-8 w-8 rounded-xl bg-slate-100 flex items-center justify-center text-slate-500">
                <UserIcon className="h-4.5 w-4.5" />
              </div>
            </div>

            {/* Logout button */}
            <button
              onClick={onLogout}
              className="bg-slate-50 hover:bg-orange-50 hover:text-orange-600 text-slate-500 p-2.5 rounded-xl cursor-pointer transition-all"
              title="خروج از حساب"
            >
              <LogOut className="h-5 w-5" />
            </button>
          </div>

        </div>
      </div>
    </header>
  );
}
