import React, { useState } from 'react';
import { motion } from 'motion/react';
import { User, Sparkles, Loader2, Tag } from 'lucide-react';
import { UserSession } from '../types';

interface AuthModalProps {
  onLogin: (session: UserSession) => void;
}

export default function AuthModal({ onLogin }: AuthModalProps) {
  const [name, setName] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      setError('لطفاً نام و نام‌خانوادگی خود را وارد کنید.');
      return;
    }

    setLoading(true);
    setError('');

    // Simulate a brief premium loading animation for a smooth experience
    setTimeout(() => {
      onLogin({
        name: name.trim(),
        email: '',
        phone: '',
        isAdmin: false,
      });
      setLoading(false);
    }, 800);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <motion.div
        initial={{ opacity: 0, scale: 0.95, y: 15 }}
        animate={{ opacity: 1, scale: 1, y: 0 }}
        transition={{ duration: 0.3 }}
        className="w-full max-w-sm overflow-hidden rounded-3xl bg-white shadow-2xl border border-slate-200"
      >
        {/* Header */}
        <div className="bg-slate-900 px-6 py-8 text-center text-white border-b border-slate-800 relative">
          <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-2xl bg-orange-500/10 border border-orange-500/20 backdrop-blur-md">
            <Tag className="h-7 w-7 text-orange-500 transform rotate-45" />
          </div>
          
          <h2 className="text-xl font-extrabold tracking-tight">خوش آمدید به sockuraaa</h2>
          <p className="mt-2 text-xs text-slate-400">
            برای ورود سریع کافیست نام خود را وارد کنید
          </p>
        </div>

        {/* Content */}
        <div className="p-6">
          {error && (
            <div className="rounded-xl bg-orange-50 p-3 text-xs text-orange-700 border border-orange-100 mb-4 text-right">
              <span>{error}</span>
            </div>
          )}

          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-xs font-bold text-slate-500 mb-1.5 flex items-center gap-1.5 justify-start">
                <User className="h-4 w-4 text-slate-400" />
                نام و نام‌خانوادگی
              </label>
              <input
                type="text"
                required
                disabled={loading}
                autoFocus
                placeholder="مثال: رضا محمدی"
                value={name}
                onChange={(e) => { setName(e.target.value); setError(''); }}
                className="w-full rounded-xl border border-slate-200 px-4 py-3 text-right text-slate-800 outline-none focus:border-orange-500 focus:ring-1 focus:ring-orange-500 text-xs font-semibold bg-slate-50/50"
              />
            </div>

            <button
              type="submit"
              disabled={loading}
              className="w-full cursor-pointer rounded-xl bg-orange-500 py-3 font-semibold text-white transition-all hover:bg-orange-600 text-xs shadow-sm flex items-center justify-center gap-1.5 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {loading ? (
                <Loader2 className="h-4 w-4 animate-spin" />
              ) : (
                <Sparkles className="h-4 w-4" />
              )}
              <span>{loading ? 'در حال ورود...' : 'ورود به فروشگاه'}</span>
            </button>
          </form>
        </div>
      </motion.div>
    </div>
  );
}
