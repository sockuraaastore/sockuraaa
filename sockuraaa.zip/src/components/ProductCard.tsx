import React from 'react';
import { Star, ArrowLeft } from 'lucide-react';
import { SockProduct } from '../types';

interface ProductCardProps {
  product: SockProduct;
  onSelect: (product: SockProduct) => void;
  key?: string;
}

export default function ProductCard({ product, onSelect }: ProductCardProps) {
  // Compute average rating from comments
  const averageRating = product.comments.length > 0 
    ? (product.comments.reduce((acc, curr) => acc + curr.rating, 0) / product.comments.length).toFixed(1)
    : '۵.۰'; // Default rating if no comments

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR');
  };

  return (
    <div 
      onClick={() => onSelect(product)}
      className="group bg-white rounded-3xl border border-slate-200 hover:border-orange-200 shadow-sm hover:shadow-md transition-all duration-300 overflow-hidden flex flex-col justify-between cursor-pointer"
    >
      <div>
        {/* Product image with light-gray container */}
        <div className="relative aspect-square overflow-hidden bg-slate-50 flex items-center justify-center p-4">
          <img
            src={product.image}
            alt={product.name}
            referrerPolicy="no-referrer"
            className="w-full h-full object-contain transform group-hover:scale-105 transition-transform duration-500"
          />
          <span className="absolute top-3 right-3 bg-white/90 backdrop-blur-xs text-[10px] font-bold text-slate-500 px-2 py-1 rounded-lg border border-slate-200">
            {product.category}
          </span>
        </div>

        {/* Info */}
        <div className="p-4 space-y-2">
          {/* Rating & reviews */}
          <div className="flex items-center gap-1">
            <Star className="h-3.5 w-3.5 fill-amber-400 text-amber-400" />
            <span className="text-xs font-semibold text-slate-700">{averageRating}</span>
            <span className="text-[10px] text-slate-400">({product.comments.length.toLocaleString('fa-IR')} نظر)</span>
          </div>

          {/* Name */}
          <h3 className="text-sm font-bold text-slate-800 leading-relaxed line-clamp-2 group-hover:text-orange-500 transition-colors">
            {product.name}
          </h3>
          
          {/* Short specs bullet */}
          <div className="flex flex-wrap gap-1 text-[10px] text-slate-405 pt-1">
            <span className="bg-slate-100 px-2 py-0.5 rounded-md text-slate-500">{product.specs.material.split('،')[0]}</span>
            <span className="bg-slate-100 px-2 py-0.5 rounded-md text-slate-500">{product.specs.type}</span>
          </div>
        </div>
      </div>

      {/* Footer / Price & action */}
      <div className="p-4 border-t border-slate-100 flex items-center justify-between bg-slate-50/50">
        <div className="text-right">
          <span className="text-lg font-extrabold text-slate-900">{formatPrice(product.price)}</span>
          <span className="text-[10px] text-slate-500 mr-1">تومان</span>
        </div>
        <div className="h-8 w-8 rounded-xl bg-orange-50 group-hover:bg-orange-500 flex items-center justify-center text-orange-600 group-hover:text-white transition-colors">
          <ArrowLeft className="h-4 w-4" />
        </div>
      </div>
    </div>
  );
}
