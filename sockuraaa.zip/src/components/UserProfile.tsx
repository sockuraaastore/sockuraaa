import React from 'react';
import { ShoppingBag, Calendar, CreditCard, Clock, CheckCircle2, XCircle, Tag } from 'lucide-react';
import { Order, UserSession } from '../types';

interface UserProfileProps {
  orders: Order[];
  session: UserSession;
}

export default function UserProfile({ orders, session }: UserProfileProps) {
  // Filter orders corresponding to this user by match on userName
  const userOrders = orders.filter(o => o.userName === session.name || o.userId === session.name);

  const formatPrice = (price: number) => {
    return price.toLocaleString('fa-IR');
  };

  const getStatusBadge = (status: Order['status']) => {
    switch (status) {
      case 'approved':
        return (
          <span className="inline-flex items-center gap-1 bg-emerald-50 text-emerald-700 border border-emerald-200 px-2.5 py-1 rounded-full text-xs font-bold font-sans">
            <CheckCircle2 className="h-3.5 w-3.5" />
            <span>تایید شده و آماده ارسال 🚚</span>
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center gap-1 bg-red-50 text-red-700 border border-red-200 px-2.5 py-1 rounded-full text-xs font-bold font-sans">
            <XCircle className="h-3.5 w-3.5" />
            <span>تراکنش رد شد / نامعتبر</span>
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 bg-amber-50 text-amber-700 border border-amber-200 px-2.5 py-1 rounded-full text-xs font-bold font-sans">
            <Clock className="h-3.5 w-3.5 animate-pulse" />
            <span>در انتظار تایید ادمین...</span>
          </span>
        );
    }
  };

  return (
    <div className="space-y-6">
      {/* User summary card header */}
      <div className="bg-white rounded-3xl p-6 border border-slate-200 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <span className="text-xs font-semibold text-slate-400">پنل حساب کاربری خریدار</span>
          <h2 className="text-xl font-bold text-slate-800 mt-1">{session.name}</h2>
          <div className="flex flex-wrap gap-x-4 gap-y-1 mt-2 text-xs text-slate-500 font-sans">
            <span className="text-slate-400">خوش آمدید به فروشگاه تخصصی جوراب sockuraaa</span>
          </div>
        </div>

        <div className="bg-orange-50/50 rounded-2xl px-4 py-3 border border-orange-100 flex items-center gap-3">
          <div className="h-10 w-10 rounded-xl bg-orange-500 flex items-center justify-center text-white font-bold text-sm shrink-0 shadow-xs">
            {userOrders.length.toLocaleString('fa-IR')}
          </div>
          <div>
            <span className="text-xs text-slate-500 block">تعداد کل خریدها</span>
            <strong className="text-xs font-bold text-orange-600 font-sans">پنل مشتری sockuraaa</strong>
          </div>
        </div>
      </div>

      {/* Orders log */}
      <div>
        <h3 className="text-sm font-extrabold text-slate-800 mb-4 flex items-center gap-2 px-1">
          <ShoppingBag className="h-4.5 w-4.5 text-orange-500" />
          <span>تاریخچه سفارشات ثبت شده</span>
        </h3>

        {userOrders.length === 0 ? (
          <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-10 text-center">
            <div className="mx-auto h-12 w-12 rounded-full bg-slate-50 flex items-center justify-center border border-slate-200 mb-4 text-slate-400">
              <ShoppingBag className="h-6 w-6" />
            </div>
            <h4 className="text-sm font-bold text-slate-700">هیچ سفارش خریدی یافت نشد</h4>
            <p className="mt-2 text-xs text-slate-400 max-w-sm mx-auto leading-relaxed">
              شما تا کنون خریدی ثبت نکرده‌اید. با انتخاب جوراب‌ها و تسویه‌حساب کارت‌به‌کارت فاکتورهای شما در اینجا قرار می‌گیرند.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {userOrders.map((order) => (
              <div 
                key={order.id} 
                className="bg-white rounded-3xl border border-slate-200 shadow-sm overflow-hidden"
              >
                {/* Order Top Bar Info */}
                <div className="bg-slate-50/75 border-b border-slate-200 px-5 py-4 flex flex-wrap items-center justify-between gap-3">
                  <div className="flex flex-wrap items-center gap-y-2 gap-x-4 text-xs font-semibold text-slate-500">
                    <span className="text-slate-800 font-bold bg-white px-2 py-0.5 border border-slate-300 rounded-lg">
                      کد سفارش: #{order.id}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="h-3.5 w-3.5 text-slate-400" />
                      {order.date}
                    </span>
                    <span className="flex items-center gap-1 text-slate-700">
                      <CreditCard className="h-3.5 w-3.5 text-slate-400" />
                      کارت واریز شده: <strong className="font-mono text-slate-800" dir="ltr">{order.cardNumber}</strong>
                    </span>
                  </div>

                  {getStatusBadge(order.status)}
                </div>

                {/* Order Products List */}
                <div className="p-5">
                  <div className="divide-y divide-slate-100">
                    {order.items.map((item) => (
                      <div key={item.productId} className="py-3 flex items-center justify-between gap-4">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 bg-slate-50 border border-slate-200 rounded-xl p-1 flex items-center justify-center shrink-0 animate-pulse-slow">
                            <img src={item.image} alt={item.name} className="max-h-full object-contain" referrerPolicy="no-referrer" />
                          </div>
                          <div>
                            <span className="text-xs font-bold text-slate-800 block line-clamp-1">{item.name}</span>
                            <span className="text-[10px] text-slate-400 font-sans block">
                              {item.quantity.toLocaleString('fa-IR')} عدد × {formatPrice(item.price)} تومان
                            </span>
                          </div>
                        </div>

                        <div className="text-left shrink-0 font-extrabold text-xs text-slate-800">
                          {formatPrice(item.price * item.quantity)} تومان
                        </div>
                      </div>
                    ))}
                  </div>

                  {/* Delivery details submitted */}
                  {(order.userPhone || order.postalCode || order.address) && (
                    <div className="bg-slate-50 border border-slate-200 rounded-2xl p-4 mt-4 text-xs space-y-2">
                      <p className="font-bold text-slate-800">📋 اطلاعات تحویل و نشانی ارسال پستی:</p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-slate-600">
                        {order.userPhone && (
                          <div>
                            <span className="font-semibold text-slate-400 ml-1">شماره همراه:</span>
                            <span className="font-sans font-bold text-slate-700">{order.userPhone}</span>
                          </div>
                        )}
                        {order.postalCode && (
                          <div>
                            <span className="font-semibold text-slate-400 ml-1">کد پستی ۱۰ رقمی:</span>
                            <span className="font-sans font-bold text-slate-705">{order.postalCode}</span>
                          </div>
                        )}
                      </div>
                      {order.address && (
                        <div className="text-slate-600 pt-2 border-t border-slate-200">
                          <span className="font-semibold text-slate-400 ml-1">نشانی دقیق گیرنده:</span>
                          <span className="text-slate-800 font-semibold">{order.address}</span>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Admin notes (rejection details or shipping details) */}
                  {order.adminNotes && (
                    <div className={`mt-4 p-4 rounded-2xl border ${
                      order.status === 'approved' 
                        ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950' 
                        : 'bg-orange-50/70 border-orange-200 text-orange-950'
                    } text-xs space-y-1.5`}>
                      <p className="font-extrabold flex items-center gap-1.5">
                        <span className="relative flex h-2 w-2">
                          <span className={`${order.status === 'approved' ? 'bg-emerald-500' : 'bg-orange-500'} relative inline-flex rounded-full h-2 w-2`}></span>
                        </span>
                        <span>پیام مدیریت واحد سفارشات sockuraaa:</span>
                      </p>
                      <p className="leading-relaxed font-semibold bg-white/75 p-2 rounded-xl border border-slate-200/50">{order.adminNotes}</p>
                    </div>
                  )}

                  {/* Order Footer summary */}
                  <div className="mt-4 pt-4 border-t border-slate-100 flex flex-wrap gap-4 items-center justify-between bg-slate-50/50 p-3 rounded-2xl border border-dashed border-slate-200">
                    <div className="text-xs text-slate-500 font-semibold">
                      شماره پیگیری پرداخت: <strong className="text-slate-800 bg-white border border-slate-200 px-2 py-0.5 rounded text-[11px] font-sans">{order.refNumber}</strong>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className="text-xs text-slate-500 font-bold">مجموع مبلغ پرداختی:</span>
                      <strong className="text-lg font-black text-orange-600">{formatPrice(order.totalPrice)}</strong>
                      <span className="text-xs text-slate-500">تومان</span>
                    </div>
                  </div>
                </div>

              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
