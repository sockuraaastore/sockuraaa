import React, { useState, useEffect } from 'react';
import { AnimatePresence } from 'motion/react';
import { Tag, Sparkles, MessageSquare, ShieldAlert, BadgeInfo, Star, CreditCard } from 'lucide-react';
import { SockProduct, Order, SupportTicket, Comment, UserSession, OrderItem, PromoBanner } from './types';
import {
  loadProducts,
  saveProducts,
  loadCategories,
  saveCategories,
  loadOrders,
  saveOrders,
  loadTickets,
  saveTickets,
  loadBanners,
  saveBanners,
} from './data';

// Components
import AuthModal from './components/AuthModal';
import Navbar from './components/Navbar';
import ProductCard from './components/ProductCard';
import ProductDetailModal from './components/ProductDetailModal';
import Cart from './components/Cart';
import UserProfile from './components/UserProfile';
import SupportChat from './components/SupportChat';
import AdminPanel from './components/AdminPanel';
import BannerDetailModal from './components/BannerDetailModal';

export default function App() {
  // Session details hold
  const [session, setSession] = useState<UserSession | null>(null);

  // States
  const [products, setProducts] = useState<SockProduct[]>([]);
  const [categories, setCategories] = useState<string[]>([]);
  const [orders, setOrders] = useState<Order[]>([]);
  const [tickets, setTickets] = useState<SupportTicket[]>([]);
  const [cart, setCart] = useState<OrderItem[]>([]);
  const [banners, setBanners] = useState<PromoBanner[]>([]);

  // Filtering states
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('همه جوراب‌ها');
  
  // UI toggles
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<SockProduct | null>(null);
  const [selectedBanner, setSelectedBanner] = useState<PromoBanner | null>(null);
  const [activeTab, setActiveTab] = useState<'shop' | 'orders' | 'support' | 'admin'>('shop');

  // Check if client has new unread replies in their support ticket
  const [hasNewReplies, setHasNewReplies] = useState(false);

  // Load resources from localStorage
  useEffect(() => {
    // Session load
    const storedSession = localStorage.getItem('socks_shop_user_session');
    if (storedSession) {
      setSession(JSON.parse(storedSession));
    }

    // Cart load
    const storedCart = localStorage.getItem('socks_shop_cart');
    if (storedCart) {
      setCart(JSON.parse(storedCart));
    }

    setProducts(loadProducts());
    setCategories(loadCategories());
    setOrders(loadOrders());
    setTickets(loadTickets());
    setBanners(loadBanners());
  }, []);

  // Sync session and cart to localStorage immediately on changes
  useEffect(() => {
    if (session) {
      localStorage.setItem('socks_shop_user_session', JSON.stringify(session));
      // Reset view tabs permissions
      if (session.isAdmin && activeTab !== 'admin' && activeTab !== 'shop') {
        setActiveTab('admin');
      }
    } else {
      localStorage.removeItem('socks_shop_user_session');
    }
  }, [session]);

  useEffect(() => {
    localStorage.setItem('socks_shop_cart', JSON.stringify(cart));
  }, [cart]);

  // Detect support replies for client notifications
  useEffect(() => {
    if (session && !session.isAdmin) {
      const userTicket = tickets.find(t => t.userPhone === session.phone || t.userId === session.phone);
      if (userTicket && userTicket.messages.length > 0) {
        const lastMsg = userTicket.messages[userTicket.messages.length - 1];
        if (lastMsg.sender === 'admin' && activeTab !== 'support') {
          setHasNewReplies(true);
        }
      }
    }
  }, [tickets, session, activeTab]);

  // Handle support notifications clean up
  useEffect(() => {
    if (activeTab === 'support') {
      setHasNewReplies(false);
    }
  }, [activeTab]);

  const handleLogin = (userSession: UserSession) => {
    setSession(userSession);
    setActiveTab(userSession.isAdmin ? 'admin' : 'shop');
  };

  const handleBecomeAdmin = () => {
    if (session) {
      const updatedSession = { ...session, isAdmin: true };
      setSession(updatedSession);
      setActiveTab('admin');
    }
  };

  const handleLogout = () => {
    setSession(null);
    setCart([]);
    setActiveTab('shop');
    setSelectedCategory('همه جوراب‌ها');
  };

  // --- CART CRUD HANDLERS ---
  const handleAddToCart = (product: SockProduct, quantity: number) => {
    setCart((prevCart) => {
      const existing = prevCart.find((item) => item.productId === product.id);
      if (existing) {
        return prevCart.map((item) =>
          item.productId === product.id
            ? { ...item, quantity: item.quantity + quantity }
            : item
        );
      }
      return [
        ...prevCart,
        {
          productId: product.id,
          name: product.name,
          price: product.price,
          quantity,
          image: product.image,
        },
      ];
    });
  };

  const handleUpdateCartQuantity = (productId: string, delta: number) => {
    setCart((prevCart) => {
      return prevCart
        .map((item) => {
          if (item.productId === productId) {
            const newQty = item.quantity + delta;
            return { ...item, quantity: newQty };
          }
          return item;
        })
        .filter((item) => item.quantity > 0);
    });
  };

  const handleRemoveCartItem = (productId: string) => {
    setCart((prevCart) => prevCart.filter((item) => item.productId !== productId));
  };

  const handleCheckout = (refNumber: string, cardNumber: string, phone: string, postalCode: string, address: string, receiptImage?: string) => {
    if (!session) return;
    const orderPrice = cart.reduce((acc, curr) => acc + curr.price * curr.quantity, 0);
    
    // Create new order log
    const newOrder: Order = {
      id: Math.floor(Math.random() * 900000 + 100000).toString(), // readable 6 digit ID
      userId: session.name, // Since phone is empty during login, name identifies them uniquely in local session
      userName: session.name,
      userPhone: phone,
      userEmail: session.email || '',
      items: [...cart],
      totalPrice: orderPrice,
      cardNumber,
      refNumber,
      date: new Date().toLocaleDateString('fa-IR'),
      status: 'pending',
      postalCode,
      address,
      receiptImage,
    };

    const newOrders = [newOrder, ...orders];
    setOrders(newOrders);
    saveOrders(newOrders);
    
    // Empty Cart and close cart overlay
    setCart([]);
    setIsCartOpen(false);

    // Redirect to orders page so they can inspect status
    setActiveTab('orders');
    alert(`سفارش شما با کد پیگیری "${newOrder.id}" ثبت شد. پس از بررسی واریزی کارت به کارت توسط مدیریت، سفارش شما فعال خواهد شد.`);
  };

  // --- ACTIONS: CUSTOM COMMENTS MODERATION ---
  const handleAddComment = (productId: string, rawComment: Omit<Comment, 'id' | 'date' | 'isFeatured'>) => {
    const updatedProducts = products.map((p) => {
      if (p.id === productId) {
        const newC: Comment = {
          ...rawComment,
          id: 'c_' + Date.now(),
          date: new Date().toLocaleDateString('fa-IR'),
          isFeatured: false,
        };
        const updatedC = [...p.comments, newC];
        return { ...p, comments: updatedC };
      }
      return p;
    });
    setProducts(updatedProducts);
    saveProducts(updatedProducts);

    // Update active details overlay if loaded
    if (selectedProduct && selectedProduct.id === productId) {
      setSelectedProduct(updatedProducts.find((p) => p.id === productId) || null);
    }
  };

  const handleDeleteComment = (productId: string, commentId: string) => {
    const updatedProducts = products.map((p) => {
      if (p.id === productId) {
        return {
          ...p,
          comments: p.comments.filter((c) => c.id !== commentId),
        };
      }
      return p;
    });
    setProducts(updatedProducts);
    saveProducts(updatedProducts);

    if (selectedProduct && selectedProduct.id === productId) {
      setSelectedProduct(updatedProducts.find((p) => p.id === productId) || null);
    }
  };

  const handleToggleBestComment = (productId: string, commentId: string) => {
    const updatedProducts = products.map((p) => {
      if (p.id === productId) {
        return {
          ...p,
          comments: p.comments.map((c) =>
            c.id === commentId ? { ...c, isFeatured: !c.isFeatured } : c
          ),
        };
      }
      return p;
    });
    setProducts(updatedProducts);
    saveProducts(updatedProducts);

    if (selectedProduct && selectedProduct.id === productId) {
      setSelectedProduct(updatedProducts.find((p) => p.id === productId) || null);
    }
  };

  // --- CRUD: SOCKS PRODUCTS CREATOR ---
  const handleAddProduct = (newProduct: SockProduct) => {
    const updated = [newProduct, ...products];
    setProducts(updated);
    saveProducts(updated);
    alert('جوراب جدید با موفقیت به انبار فروشگاه اضافه شد!');
  };

  const handleUpdateProduct = (updatedProduct: SockProduct) => {
    const updated = products.map((p) => (p.id === updatedProduct.id ? updatedProduct : p));
    setProducts(updated);
    saveProducts(updated);
    alert('تغییرات جوراب ذخیره گردید.');
  };

  const handleDeleteProduct = (productId: string) => {
    const updated = products.filter((p) => p.id !== productId);
    setProducts(updated);
    saveProducts(updated);
  };

  // --- CRUD: CATEGORIES MANAGEMENT ---
  const handleAddCategory = (newCat: string) => {
    const updated = [...categories, newCat];
    setCategories(updated);
    saveCategories(updated);
  };

  const handleDeleteCategory = (catToDelete: string) => {
    const updatedCats = categories.filter((c) => c !== catToDelete);
    setCategories(updatedCats);
    saveCategories(updatedCats);

    // Update socks belonging to deleted category to fallback
    const updatedProds = products.map((p) =>
      p.category === catToDelete ? { ...p, category: categories[1] || 'ساق بلند' } : p
    );
    setProducts(updatedProds);
    saveProducts(updatedProds);
  };

  // --- ADMIN ORDERS TRANSITIONS ---
  const handleUpdateOrderStatus = (orderId: string, status: Order['status'], adminNotes?: string) => {
    const updated = orders.map((o) => (o.id === orderId ? { ...o, status, adminNotes } : o));
    setOrders(updated);
    saveOrders(updated);
  };

  // --- ADMIN PROMO BANNERS ---
  const handleAddBanner = (title: string, image: string, content: string) => {
    const newBanner: PromoBanner = {
      id: 'banner_' + Date.now(),
      title,
      image,
      content
    };
    const updated = [newBanner, ...banners];
    setBanners(updated);
    saveBanners(updated);
  };

  const handleDeleteBanner = (bannerId: string) => {
    const updated = banners.filter(b => b.id !== bannerId);
    setBanners(updated);
    saveBanners(updated);
  };

  // --- SUPPORT HELPDESK ENGINE ---
  const handleReplyToTicket = (ticketId: string, text: string) => {
    const updated = tickets.map((t) => {
      if (t.id === ticketId) {
        return {
          ...t,
          messages: [
            ...t.messages,
            {
              id: 'm_' + Date.now(),
              sender: 'admin' as const,
              text,
              timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
            },
          ],
        };
      }
      return t;
    });
    setTickets(updated);
    saveTickets(updated);
  };

  const handleUserSendMessage = (text: string) => {
    if (!session) return;
    
    // Check if user already shares a thread
    const userTicketIndex = tickets.findIndex(
      (t) => t.userPhone === session.phone || t.userId === session.phone
    );

    const newMessage = {
      id: 'm_' + Date.now(),
      sender: 'user' as const,
      text,
      timestamp: new Date().toLocaleTimeString('fa-IR', { hour: '2-digit', minute: '2-digit' }),
    };

    let updatedTickets: SupportTicket[] = [];

    if (userTicketIndex > -1) {
      // Thread exists, append message
      updatedTickets = tickets.map((t, idx) => {
        if (idx === userTicketIndex) {
          return {
            ...t,
            messages: [...t.messages, newMessage],
          };
        }
        return t;
      });
    } else {
      // Thread does not exist, create ticket
      const newTicket: SupportTicket = {
        id: 't_' + Date.now(),
        userId: session.phone,
        userName: session.name,
        userPhone: session.phone,
        messages: [newMessage],
      };
      updatedTickets = [newTicket, ...tickets];
    }

    setTickets(updatedTickets);
    saveTickets(updatedTickets);
  };

  // Filtering filter Logic
  const filteredProducts = products.filter((p) => {
    const matchesCategory = selectedCategory === 'همه جوراب‌ها' || p.category === selectedCategory;
    const matchesSearch = p.name.toLowerCase().includes(searchQuery.trim().toLowerCase());
    return matchesCategory && matchesSearch;
  });

  // Category Icon representations getter
  const getCategoryEmoji = (cat: string) => {
    switch (cat) {
      case 'همه جوراب‌ها': return '🧦';
      case 'ساق بلند': return '⚡';
      case 'ساق کوتاه': return '👟';
      case 'کالج': return '👞';
      case 'پشمی و زمستانی': return '❄️';
      case 'فانتزی و طرح‌دار': return '🎨';
      default: return '🧦';
    }
  };

  // Compute cart products qty count sum
  const cartQtySum = cart.reduce((acc, curr) => acc + curr.quantity, 0);

  return (
    <div className="min-h-screen bg-[#f8fafc] text-slate-850 flex flex-col justify-between selection:bg-orange-500 selection:text-white">
      {/* Dynamic Account Form Welcome layer */}
      {!session && <AuthModal onLogin={handleLogin} />}

      {/* Main Core Content wrapper if session details loaded */}
      {session && (
        <>
          <Navbar
            session={session}
            cartCount={cartQtySum}
            searchQuery={searchQuery}
            setSearchQuery={setSearchQuery}
            onLogout={handleLogout}
            onOpenCart={() => setIsCartOpen(true)}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            hasNewSupportReplies={hasNewReplies}
            onBecomeAdmin={handleBecomeAdmin}
          />

          <main className="flex-1 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full">
            
            {/* ===================== TAB 1: E-COMMERCE SOCKS SHOP ===================== */}
            {activeTab === 'shop' && (
              <div className="space-y-8">
                
                {/* Active Promo Banners Slider/Row */}
                {banners.length > 0 && (
                  <div className="space-y-3.5">
                    <span className="text-xs font-black text-slate-400 block text-right">🔥 جدیدترین کمپین‌ها و جشنواره‌های ویژه ساکورا:</span>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5 text-right">
                      {banners.map((banner) => (
                        <div
                          key={banner.id}
                          onClick={() => setSelectedBanner(banner)}
                          className="group relative h-48 rounded-3xl overflow-hidden border border-slate-205 shadow-xs cursor-pointer hover:border-orange-500 hover:shadow-md transition-all duration-300 transform hover:-translate-y-0.5"
                        >
                          {/* Image with fine scaling transition */}
                          <img
                            src={banner.image}
                            alt={banner.title}
                            className="absolute inset-0 h-full w-full object-cover group-hover:scale-105 transition-transform duration-500"
                            onError={(e) => {
                              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1582966772680-860e372bb558?w=800&q=80';
                            }}
                          />
                          {/* Rich bottom shadow gradients for strong text readability */}
                          <div className="absolute inset-0 bg-gradient-to-t from-slate-950/85 via-slate-950/40 to-transparent flex flex-col justify-end p-4 text-right">
                            <span className="bg-orange-500 text-white text-[9px] font-extrabold px-2 py-0.5 rounded-lg max-w-fit mb-2 shrink-0 animate-bounce">
                              مشاهده اطلاعیه ویژه
                            </span>
                            <h3 className="text-xs sm:text-sm font-black text-white group-hover:text-orange-300 transition-colors line-clamp-1 leading-normal">
                              {banner.title}
                            </h3>
                            <p className="text-[10px] text-slate-300 line-clamp-1 mt-1 font-sans">
                              {banner.content}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
                
                {/* Categories Slider (Like Digikala Bubble Links) */}
                <div className="space-y-4 bg-white/50 backdrop-blur-xs p-5 rounded-3xl border border-slate-200">
                  <span className="text-xs font-extrabold text-slate-400 block">دسته‌بندی‌های کالا در sockuraaa</span>
                  <div className="flex flex-wrap gap-2.5">
                    {categories.map((cat) => {
                      const isActive = selectedCategory === cat;
                      return (
                        <button
                          key={cat}
                          onClick={() => setSelectedCategory(cat)}
                          className={`flex cursor-pointer items-center gap-2 px-4 py-2.5 rounded-2xl text-xs font-bold transition-all border ${
                            isActive
                              ? 'bg-orange-500 border-orange-500 text-white shadow-sm shadow-orange-100'
                              : 'bg-white border-slate-200 hover:border-slate-300 text-slate-600 hover:bg-slate-50'
                          }`}
                        >
                          <span className="text-base leading-none">{getCategoryEmoji(cat)}</span>
                          <span>{cat}</span>
                        </button>
                      );
                    })}
                  </div>
                </div>

                {/* Socks Products Showcase Grid */}
                <div className="space-y-6">
                  <div className="flex justify-between items-center">
                    <h2 className="text-base font-extrabold text-slate-800 flex items-center gap-2">
                      <Tag className="h-5 w-5 text-orange-500" />
                      <span>{selectedCategory}</span>
                      <span className="text-xs text-slate-400 font-normal">
                        ({filteredProducts.length.toLocaleString('fa-IR')} کالا یافت شد)
                      </span>
                    </h2>
                  </div>

                  {filteredProducts.length === 0 ? (
                    <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center shadow-xs">
                      <div className="mx-auto h-12 w-12 rounded-full bg-gray-50 flex items-center justify-center text-gray-450 border border-gray-100 mb-3 font-bold text-lg">؟</div>
                      <h3 className="text-sm font-bold text-gray-700">هیچ محصولی با این فیلتر یا عبارت یافت نشد!</h3>
                      <p className="mt-2 text-xs text-gray-450 max-w-xs mx-auto leading-relaxed">
                        لطفاً دسته‌بندی دیگری انتخاب کرده یا نام جستجو شده خود را ویرایش کنید.
                      </p>
                      <button
                        onClick={() => { setSelectedCategory('همه جوراب‌ها'); setSearchQuery(''); }}
                        className="mt-4 bg-gray-150 hover:bg-gray-200 text-xs font-bold text-gray-600 px-4 py-2 rounded-xl transition-all cursor-pointer"
                      >
                        پاک کردن همه فیلترها
                      </button>
                    </div>
                  ) : (
                    <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-5">
                      {filteredProducts.map((sock) => (
                        <ProductCard
                          key={sock.id}
                          product={sock}
                          onSelect={setSelectedProduct}
                        />
                      ))}
                    </div>
                  )}
                </div>

              </div>
            )}

            {/* ===================== TAB 2: BUYING ORDERS LIST ===================== */}
            {activeTab === 'orders' && !session.isAdmin && (
              <UserProfile orders={orders} session={session} />
            )}

            {/* ===================== TAB 3: CUSTOMER SUPPORT TALK ===================== */}
            {activeTab === 'support' && !session.isAdmin && (
              <SupportChat
                tickets={tickets}
                session={session}
                onSendMessage={handleUserSendMessage}
              />
            )}

            {/* ===================== TAB 4: SYSTEM ADMIN PANEL ===================== */}
            {activeTab === 'admin' && session.isAdmin && (
              <AdminPanel
                products={products}
                categories={categories}
                orders={orders}
                tickets={tickets}
                banners={banners}
                onAddProduct={handleAddProduct}
                onUpdateProduct={handleUpdateProduct}
                onDeleteProduct={handleDeleteProduct}
                onAddCategory={handleAddCategory}
                onDeleteCategory={handleDeleteCategory}
                onUpdateOrderStatus={handleUpdateOrderStatus}
                onReplyToTicket={handleReplyToTicket}
                onDeleteComment={handleDeleteComment}
                onToggleBestComment={handleToggleBestComment}
                onAddBanner={handleAddBanner}
                onDeleteBanner={handleDeleteBanner}
              />
            )}

          </main>

          {/* Core Footer */}
          <footer className="border-t border-slate-200 bg-white py-6 mt-16 text-center text-xs text-slate-400">
            <div className="max-w-7xl mx-auto px-4 flex flex-col md:flex-row items-center justify-between gap-4">
              <span>کلیه حقوق این سامانه متعلق به تولیدی و عکاسی بزرگ sockuraaa می‌باشد.</span>
              <div className="flex flex-col items-center md:items-end gap-1 text-slate-500 font-sans font-bold">
                <div className="flex items-center gap-1.5">
                  <CreditCard className="h-4 w-4 text-orange-500" />
                  <span>شماره کارت واریز:</span>
                  <span className="text-slate-800 font-mono tracking-wide" dir="ltr">۶۰۳۷-۷۰۱۴-۴۷۰۹-۱۵۲۸</span>
                </div>
                <span className="text-[10px] text-slate-400">بنام نسترن محمدیان خلیفه کندی</span>
              </div>
            </div>
          </footer>

          {/* Left Shopping Cart drawer overlay */}
          <AnimatePresence>
            {isCartOpen && (
              <Cart
                cartItems={cart}
                onUpdateQuantity={handleUpdateCartQuantity}
                onRemoveItem={handleRemoveCartItem}
                onCheckout={handleCheckout}
                onClose={() => setIsCartOpen(false)}
              />
            )}
          </AnimatePresence>

          {/* Details visual modal popup overlay */}
          <AnimatePresence>
            {selectedProduct && (
              <ProductDetailModal
                product={selectedProduct}
                session={session}
                onClose={() => setSelectedProduct(null)}
                onAddToCart={handleAddToCart}
                onAddComment={handleAddComment}
                onDeleteComment={handleDeleteComment}
                onToggleBestComment={handleToggleBestComment}
              />
            )}
          </AnimatePresence>

          {/* Banner details visual modal popup overlay */}
          <AnimatePresence>
            {selectedBanner && (
              <BannerDetailModal
                banner={selectedBanner}
                onClose={() => setSelectedBanner(null)}
              />
            )}
          </AnimatePresence>
        </>
      )}

    </div>
  );
}
