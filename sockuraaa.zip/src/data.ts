import { SockProduct, Order, SupportTicket, PromoBanner } from './types';

export const INITIAL_CATEGORIES = [
  'همه جوراب‌ها',
  'ساق بلند',
  'ساق کوتاه',
  'کالج',
  'پشمی و زمستانی',
  'فانتزی و طرح‌دار'
];

export const INITIAL_PRODUCTS: SockProduct[] = [];

export const INITIAL_BANNERS: PromoBanner[] = [
  {
    id: 'b1',
    title: 'جشنواره بزرگ جوراب‌های رنگارنگ نخ پنبه sockuraaa 🧦',
    image: 'https://images.unsplash.com/photo-1582966772680-860e372bb558?auto=format&fit=crop&q=80&w=1200',
    content: 'به دنیای رنگارنگ جوراب‌های نخ‌پنبه و ضدحساسیت فروشگاه ساکورا خوش آمدید! در این جشنواره فوق‌العاده تمامی مدل‌های ساق‌بلند، ساق‌کوتاه، کالج و فانتزی با ۳۰ الی ۵۰ درصد تخفیف ویژه به فروش می‌رسند. ارسال برای خریدهای بالای ۳ جفت جوراب به سراسر ایران رایگان خواهد بود. همچنین کیفیت تمام جوراب‌ها ۱۰۰٪ تضمین پایداری رنگ و بافت پس از شست‌وشو را دارند.'
  }
];

// LocalStorage keys
const KEYS = {
  PRODUCTS: 'socks_shop_products',
  CATEGORIES: 'socks_shop_categories',
  ORDERS: 'socks_shop_orders',
  TICKETS: 'socks_shop_tickets',
  USER: 'socks_shop_user_session',
  BANNERS: 'socks_shop_banners',
};

export const loadProducts = (): SockProduct[] => {
  const data = localStorage.getItem(KEYS.PRODUCTS);
  if (!data) {
    localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(INITIAL_PRODUCTS));
    return INITIAL_PRODUCTS;
  }
  try {
    const parsed = JSON.parse(data) as SockProduct[];
    // Auto-wipe the old preloaded sample mock data with ID '1'-'5' so it doesn't linger in user's browser
    if (parsed.some(p => p.id === '1' || p.id === '2' || p.id === '3' || p.id === '4' || p.id === '5')) {
      localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(INITIAL_PRODUCTS));
      return INITIAL_PRODUCTS;
    }
    return parsed;
  } catch (e) {
    return INITIAL_PRODUCTS;
  }
};

export const saveProducts = (products: SockProduct[]) => {
  localStorage.setItem(KEYS.PRODUCTS, JSON.stringify(products));
};

export const loadCategories = (): string[] => {
  const data = localStorage.getItem(KEYS.CATEGORIES);
  if (!data) {
    localStorage.setItem(KEYS.CATEGORIES, JSON.stringify(INITIAL_CATEGORIES));
    return INITIAL_CATEGORIES;
  }
  try {
    const parsed = JSON.parse(data) as string[];
    return parsed;
  } catch (e) {
    return INITIAL_CATEGORIES;
  }
};

export const saveCategories = (categories: string[]) => {
  localStorage.setItem(KEYS.CATEGORIES, JSON.stringify(categories));
};

export const loadOrders = (): Order[] => {
  const data = localStorage.getItem(KEYS.ORDERS);
  try {
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
};

export const saveOrders = (orders: Order[]) => {
  localStorage.setItem(KEYS.ORDERS, JSON.stringify(orders));
};

export const loadTickets = (): SupportTicket[] => {
  const data = localStorage.getItem(KEYS.TICKETS);
  try {
    return data ? JSON.parse(data) : [];
  } catch (e) {
    return [];
  }
};

export const saveTickets = (tickets: SupportTicket[]) => {
  localStorage.setItem(KEYS.TICKETS, JSON.stringify(tickets));
};

export const loadBanners = (): PromoBanner[] => {
  const data = localStorage.getItem(KEYS.BANNERS);
  if (!data) {
    localStorage.setItem(KEYS.BANNERS, JSON.stringify(INITIAL_BANNERS));
    return INITIAL_BANNERS;
  }
  try {
    return JSON.parse(data) as PromoBanner[];
  } catch (e) {
    return INITIAL_BANNERS;
  }
};

export const saveBanners = (banners: PromoBanner[]) => {
  localStorage.setItem(KEYS.BANNERS, JSON.stringify(banners));
};
