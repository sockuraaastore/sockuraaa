export interface Comment {
  id: string;
  userName: string;
  rating: number;
  text: string;
  date: string;
  isFeatured: boolean;
}

export interface SockProduct {
  id: string;
  name: string;
  price: number; // in Tomans
  image: string;
  category: string;
  description: string;
  specs: {
    material: string; // جنس
    size: string; // سایز
    type: string; // نوع (زنانه/مردانه/بچگانه)
    thickness: string; // ضخامت
  };
  comments: Comment[];
}

export interface OrderItem {
  productId: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

export interface Order {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  userEmail: string;
  items: OrderItem[];
  totalPrice: number;
  cardNumber: string;
  refNumber: string; // شماره پیگیری یا نام واریز کننده
  date: string;
  status: 'pending' | 'approved' | 'rejected';
  postalCode?: string;
  address?: string;
  receiptImage?: string;
  adminNotes?: string;
}

export interface SupportTicket {
  id: string;
  userId: string;
  userName: string;
  userPhone: string;
  messages: {
    id: string;
    sender: 'user' | 'admin';
    text: string;
    timestamp: string;
  }[];
}

export interface UserSession {
  name: string;
  email: string;
  phone: string;
  isAdmin: boolean;
}

export interface PromoBanner {
  id: string;
  title: string;
  image: string;
  content: string;
}
