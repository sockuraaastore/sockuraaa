import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import nodemailer from "nodemailer";
import dotenv from "dotenv";

dotenv.config();

// In-memory store for verification codes
interface VerificationData {
  code: string;
  name: string;
  phone: string;
  timestamp: number;
}
const verificationCodes = new Map<string, VerificationData>();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Send Auth Verification Code
  app.post("/api/auth/send-code", async (req, res) => {
    const { email, name, phone } = req.body;

    if (!email || !name || !phone) {
      return res.status(400).json({ success: false, message: "تمامی فیلدها الزامی هستند." });
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanPhone = phone.trim();

    // Generate random 5-digit code
    const code = Math.floor(10000 + Math.random() * 90000).toString();

    // Save in memory
    verificationCodes.set(cleanEmail, {
      code,
      name: name.trim(),
      phone: cleanPhone,
      timestamp: Date.now(),
    });

    const emailUser = process.env.EMAIL_USER;
    const emailPass = process.env.EMAIL_PASS;

    if (!emailUser || !emailPass) {
      // Graceful fallback when credentials are not configured
      return res.json({
        success: true,
        email: cleanEmail,
        realSent: false,
        code, // Return code so they can log in offline/during setup
        message: "تنظیمات ایمیل (EMAIL_USER) انجام نشده است. ورود شبیه‌سازی شد.",
      });
    }

    try {
      const host = process.env.EMAIL_HOST || "smtp.gmail.com";
      const port = parseInt(process.env.EMAIL_PORT || "465", 10);
      const from = process.env.EMAIL_FROM || `"فروشگاه جوراب سوکورا" <${emailUser}>`;

      const transporter = nodemailer.createTransport({
        host,
        port,
        secure: port === 465,
        auth: {
          user: emailUser,
          pass: emailPass,
        },
        tls: {
          rejectUnauthorized: false,
        },
      });

      const mailOptions = {
        from,
        to: cleanEmail,
        subject: "کد تأیید ورود به فروشگاه جوراب sockuraaa",
        html: `
          <div style="direction: rtl; font-family: Tahoma, sans-serif; padding: 20px; border: 1px solid #e2e8f0; border-radius: 12px; max-width: 500px; margin: auto; background-color: #f8fafc; text-align: right;">
            <div style="text-align: center; margin-bottom: 20px;">
              <h2 style="color: #f97316; margin: 0;">فروشگاه جوراب sockuraaa</h2>
              <p style="color: #64748b; font-size: 13px;">بزرگترین مرجع تخصصی فانتزی جوراب ایران</p>
            </div>
            
            <p style="font-size: 14px; color: #334155;">سلام <strong>${name}</strong> عزیز،</p>
            <p style="font-size: 13px; color: #334155; line-height: 1.6;">برای ورود به حساب کاربری خود در فروشگاه جوراب سوکورا، لطفا از کد تأیید یکبار مصرف زیر استفاده فرمایید:</p>
            
            <div style="background-color: #f1f5f9; padding: 15px; border-radius: 8px; text-align: center; margin: 25px 0; border: 1px solid #e2e8f0;">
              <span style="font-size: 24px; font-weight: bold; letter-spacing: 6px; color: #0f172a; font-family: monospace;">${code}</span>
            </div>
            
            <p style="font-size: 11px; color: #94a3b8; text-align: center; margin-top: 30px; border-top: 1px solid #f1f5f9; padding-top: 12px;">این پیام به صورت خودکار از سیستم ارسال شده است. لطفاً از پاسخ دادن به آن خودداری کنید.</p>
          </div>
        `,
      };

      await transporter.sendMail(mailOptions);
      return res.json({
        success: true,
        email: cleanEmail,
        realSent: true,
        message: "کد تایید با موفقیت به ایمیل شما ارسال شد.",
      });
    } catch (err: any) {
      console.error("Failed to send email via SMTP:", err);
      return res.json({
        success: true,
        email: cleanEmail,
        realSent: false,
        code, // Return code in response as fallback so they aren't locked out
        warning: `خطا در ارسال ایمیل واقعی: ${err.message || err}. برای سهولت، از کد زیر استفاده کنید.`,
      });
    }
  });

  // API Route: Verify Auth Code
  app.post("/api/auth/verify-code", (req, res) => {
    const { email, code } = req.body;

    if (!email || !code) {
      return res.status(400).json({ success: false, message: "ایمیل و کد الزامی هستند." });
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanCode = code.trim();

    const data = verificationCodes.get(cleanEmail);

    if (!data) {
      return res.status(400).json({ success: false, message: "کد تأییدی برای این ایمیل صادر نشده یا منقضی شده است." });
    }

    if (data.code !== cleanCode) {
      return res.status(400).json({ success: false, message: "کد تأیید وارد شده نادرست است." });
    }

    // Determine if Admin by email matching
    const isAdmin = cleanEmail === 'admin@sockuraaa.ir' && data.phone === '09121234567';

    const session = {
      name: data.name,
      email: cleanEmail,
      phone: data.phone,
      isAdmin,
    };

    // Clean up code after successful verification so it cannot be reused
    verificationCodes.delete(cleanEmail);

    return res.json({
      success: true,
      session,
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
